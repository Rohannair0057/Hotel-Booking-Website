<?php
session_start();
require_once 'includes/db.php'; // Use '../includes/db.php' if this file is in /admin

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle room deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM rooms WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    header("Location: manage_rooms.php");
    exit;
}

// Fetch all rooms with hotel and type info
$sql = "SELECT rooms.*, destinations.name AS hotel_name, room_types.type_name 
        FROM rooms 
        JOIN destinations ON rooms.destination_id = destinations.id
        JOIN room_types ON rooms.room_type_id = room_types.id
        ORDER BY rooms.id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Rooms - Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8fafc; }
        .table-card { border-radius: 18px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); background: #fff; padding: 32px 24px; margin-top: 40px; }
        .table thead th { background: #f2f6fc; color: #2d3a4b; border-top: none; }
        .table-striped tbody tr:nth-of-type(odd) { background: #f8fafc; }
        .table-hover tbody tr:hover { background: #eaf4ff; }
        .room-img-thumb { width: 60px; height: 40px; object-fit: cover; border-radius: 8px; border: 2px solid #e3e3e3; }
        .badge-available { background: #38c172; color: #fff; font-size: 0.95em; border-radius: 8px; }
        .badge-full { background: #ff4d4f; color: #fff; font-size: 0.95em; border-radius: 8px; }
        .action-btn { border-radius: 8px; font-weight: 500; }
        .action-btn i { margin-right: 4px; }
        .table-responsive { margin-bottom: 0; }
    </style>
</head>
<body>
<?php include 'navbar.php'; // Or your admin navbar ?>
<div class="container">
    <div class="table-card">
        <h2 class="mb-4" style="font-weight:600; color:#2d3a4b;"><i class="fa fa-bed"></i> Manage Rooms</h2>
        <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Hotel</th>
                    <th>Room Name</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Available</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php while($room = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($room['id']) ?></td>
                    <td><?= htmlspecialchars($room['hotel_name']) ?></td>
                    <td><?= htmlspecialchars($room['name']) ?></td>
                    <td><?= htmlspecialchars($room['type_name']) ?></td>
                    <td>₹<?= htmlspecialchars($room['price']) ?></td>
                    <td>
                        <?php if ($room['available_rooms'] > 0): ?>
                            <span class="badge badge-available"><i class="fa fa-check-circle"></i> <?= htmlspecialchars($room['available_rooms']) ?> / <?= htmlspecialchars($room['total_rooms']) ?></span>
                        <?php else: ?>
                            <span class="badge badge-full"><i class="fa fa-times-circle"></i> 0 / <?= htmlspecialchars($room['total_rooms']) ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($room['image']): 
                            $images = explode(',', $room['image']);
                            $firstImage = trim($images[0]);
                        ?>
                            <img src="assets/images/<?= htmlspecialchars($firstImage) ?>" alt="Room Image" class="room-img-thumb">
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="manage_rooms.php?delete=<?= $room['id'] ?>" class="btn btn-danger btn-sm action-btn" onclick="return confirm('Are you sure you want to delete this room?');"><i class="fa fa-trash"></i>Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        </div>
        <a href="dashboard.php" class="btn btn-secondary mt-3"><i class="fa fa-arrow-left"></i> Back to Dashboard</a>
    </div>
</div>
</body>
</html>