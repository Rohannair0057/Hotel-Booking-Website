<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Growth chart data (bookings per month for last 6 months)
$months = [];
$counts = [];
for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $label = date('M Y', strtotime("-$i months"));
    $months[] = $label;
    $sql = "SELECT COUNT(*) as count FROM bookings WHERE DATE_FORMAT(created_at, '%Y-%m') = '$month'";
    $result = $conn->query($sql);
    $counts[] = $result->fetch_assoc()['count'] ?? 0;
}

// Booking events for calendar
$events = [];
$bookings = $conn->query("SELECT bookings.*, users.name as user_name, rooms.name as room_name 
    FROM bookings 
    JOIN users ON bookings.user_id = users.id 
    JOIN rooms ON bookings.room_id = rooms.id");

while($b = $bookings->fetch_assoc()) {
    $events[] = [
        'title' => $b['user_name'] . ' - ' . $b['room_name'],
        'start' => $b['check_in'],
        'end'   => date('Y-m-d', strtotime($b['check_out'] . ' +1 day')), // FullCalendar is exclusive of end date
        'color' => $b['status'] == 'Cancelled' ? '#dc3545' : ($b['status'] == 'Pending' ? '#ffc107' : '#28a745'),
        'description' => "Status: " . $b['status']
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: #fff;
            padding-top: 30px;
        }
        .sidebar a {
            color: #fff;
            display: block;
            padding: 12px 20px;
            margin-bottom: 8px;
            border-radius: 4px;
            text-decoration: none;
        }
        .sidebar a.active, .sidebar a:hover {
            background: #495057;
            color: #ffc107;
        }
        .dashboard-cards .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.07);
        }
        .dashboard-cards .card i {
            font-size: 2.5rem;
        }
        #calendar {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.07);
            padding: 20px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 sidebar">
            <h4 class="text-center mb-4"><i class="fa fa-user-shield"></i> Admin</h4>
            <a href="dashboard.php" class="active"><i class="fa fa-tachometer-alt"></i> Dashboard</a>
            <a href="manage_bookings.php"><i class="fa fa-calendar-check"></i> Manage Bookings</a>
            <a href="manage_users.php"><i class="fa fa-users"></i> Manage Users</a>
            <a href="manage_rooms.php"><i class="fa fa-bed"></i> Manage Rooms</a>
            <a href="add_room.php"><i class="fa fa-plus"></i> Add Room</a>
            <a href="view_profit.php"><i class="fa fa-chart-line"></i> View Profits</a>
            <a href="manage_payments.php"><i class="fa fa-credit-card"></i> Manage Payments</a>
            <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
        </nav>
        <!-- Main Content -->
        <main class="col-md-10 py-4">
            <h2 class="mb-4">Admin Dashboard</h2>
            <div class="mb-5">
                <h5>Website Growth (Bookings per Month)</h5>
                <canvas id="growthChart" height="80"></canvas>
            </div>
            <div class="mb-5">
                <h5 class="mb-3" style="font-weight:600;"><i class="fa fa-calendar-alt text-primary"></i> Booking Calendar</h5>
                <!-- Calendar Legend -->
                <div class="mb-3 d-flex align-items-center">
                    <span class="badge mr-2" style="background:#28a745;">Confirmed</span>
                    <span class="badge mr-2" style="background:#ffc107; color:#212529;">Pending</span>
                    <span class="badge mr-2" style="background:#dc3545;">Cancelled</span>
                </div>
                <div id="calendar"></div>
            </div>
            <hr>
            <h5>Quick Actions</h5>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <a href="manage_bookings.php" class="text-decoration-none">
                        <div class="card text-center shadow-sm action-card h-100" style="transition:transform 0.2s;">
                            <div class="card-body">
                                <i class="fa fa-calendar-check fa-2x text-primary mb-2"></i>
                                <h6 class="card-title">Manage Bookings</h6>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="manage_users.php" class="text-decoration-none">
                        <div class="card text-center shadow-sm action-card h-100" style="transition:transform 0.2s;">
                            <div class="card-body">
                                <i class="fa fa-users fa-2x text-success mb-2"></i>
                                <h6 class="card-title">Manage Users</h6>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="manage_rooms.php" class="text-decoration-none">
                        <div class="card text-center shadow-sm action-card h-100" style="transition:transform 0.2s;">
                            <div class="card-body">
                                <i class="fa fa-bed fa-2x text-warning mb-2"></i>
                                <h6 class="card-title">Manage Rooms</h6>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="add_room.php" class="text-decoration-none">
                        <div class="card text-center shadow-sm action-card h-100" style="transition:transform 0.2s;">
                            <div class="card-body">
                                <i class="fa fa-plus fa-2x text-info mb-2"></i>
                                <h6 class="card-title">Add Room</h6>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </main>
    </div>
</div>
<script>
const ctx = document.getElementById('growthChart').getContext('2d');
const growthChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?= json_encode($months) ?>,
        datasets: [{
            label: 'Bookings',
            data: <?= json_encode($counts) ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: '#007bff',
            borderWidth: 2,
            pointBackgroundColor: '#007bff',
            pointRadius: 5,
            fill: true,
            tension: 0.3
        }]
    },
    options: {
        scales: {
            y: { beginAtZero: true, precision:0 }
        }
    }
});

// FullCalendar
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        height: 500,
        events: <?= json_encode($events) ?>,
        eventDidMount: function(info) {
            if (info.event.extendedProps.description) {
                info.el.title = info.event.extendedProps.description;
            }
        },
        eventClick: function(info) {
            var event = info.event;
            var details = '<b>' + event.title + '</b><br>' +
                (event.extendedProps.description ? event.extendedProps.description + '<br>' : '') +
                '<b>From:</b> ' + event.start.toLocaleDateString() + '<br>' +
                (event.end ? '<b>To:</b> ' + event.end.toLocaleDateString() + '<br>' : '');
            var modal = document.createElement('div');
            modal.innerHTML = '<div class="modal fade" id="eventModal" tabindex="-1" role="dialog">' +
                '<div class="modal-dialog modal-dialog-centered" role="document">' +
                '<div class="modal-content">' +
                '<div class="modal-header"><h5 class="modal-title">Booking Details</h5>' +
                '<button type="button" class="close" data-dismiss="modal" aria-label="Close">' +
                '<span aria-hidden="true">&times;</span></button></div>' +
                '<div class="modal-body">' + details + '</div>' +
                '</div></div></div>';
            document.body.appendChild(modal);
            $(modal).find('.modal').modal('show');
            $(modal).on('hidden.bs.modal', function() { modal.remove(); });
        },
        eventContent: function(arg) {
            let statusColor = arg.event.backgroundColor || arg.event.borderColor || '#28a745';
            let initials = arg.event.title.split(' ')[0][0]; // First letter of user name
            return {
                html: `
                    <div style="display:flex;align-items:center;">
                        <span style="background:${statusColor};color:#fff;border-radius:50%;width:22px;height:22px;display:inline-flex;align-items:center;justify-content:center;font-weight:bold;margin-right:6px;">${initials}</span>
                        <span style="font-weight:600;">${arg.event.title}</span>
                    </div>
                `
            };
        }
    });
    calendar.render();
});
</script>
<style>
.action-card:hover {
    transform: translateY(-5px) scale(1.03);
    box-shadow: 0 6px 24px rgba(0,0,0,0.12);
    border: 1px solid #007bff;
}
</style>
</body>
</html>