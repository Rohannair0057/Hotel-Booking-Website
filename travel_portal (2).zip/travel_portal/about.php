<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>About Us - Travel Portal</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(120deg, #43cea2 0%, #185a9d 100%);
            min-height: 100vh;
        }
        .about-card {
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.10);
            padding: 2.5rem 2rem;
            margin-top: 40px;
            margin-bottom: 40px;
        }
        .about-img-wrapper img {
            border: 8px solid #fff;
            border-radius: 18px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
            max-height: 320px;
            transition: transform 0.3s;
        }
        .about-img-wrapper img:hover {
            transform: scale(1.04) rotate(-2deg);
        }
        .about-badge {
            position: absolute;
            bottom: 20px;
            left: 20px;
            background: #fff;
            color: #185a9d;
            font-weight: bold;
            padding: 6px 18px;
            border-radius: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            font-size: 1.1rem;
        }
        .about-list i {
            color: #43cea2;
            margin-right: 8px;
        }
        .testimonial-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.07);
            padding: 1.5rem 1.2rem;
            margin: 1rem 0.5rem;
        }
        .testimonial-card img {
            width: 48px;
            height: 48px;
            object-fit: cover;
            border-radius: 50%;
            margin-right: 12px;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container py-5">
  <div class="about-card">
    <div class="row align-items-center">
      <div class="col-md-6 mb-4 mb-md-0">
        <div class="about-img-wrapper position-relative">
          <img src="assets/images/about-us.jpg" alt="About Us" class="img-fluid">
          <span class="about-badge">
            <i class="fa fa-star text-warning"></i> Trusted by 10,000+ travelers
          </span>
        </div>
      </div>
      <div class="col-md-6">
        <h2 class="mb-3" style="font-weight:bold; color:#185a9d;">About Us</h2>
        <p style="font-size:1.15rem; color:#333;">
          Welcome to <span style="font-weight:bold; color:#43cea2;">Travel Portal</span>!<br>
          We help you find and book the best hotels, villas, apartments, and resorts across top destinations in India.<br>
          Our mission is to make your travel and stay comfortable, affordable, and memorable.
        </p>
        <ul class="list-unstyled about-list mb-4">
          <li class="mb-2"><i class="fa fa-check-circle"></i> Best price guarantee</li>
          <li class="mb-2"><i class="fa fa-check-circle"></i> 24/7 customer support</li>
          <li class="mb-2"><i class="fa fa-check-circle"></i> Easy, secure booking</li>
        </ul>
        <a href="search.php" class="btn btn-success px-4 py-2" style="font-weight:bold; border-radius:30px;">Start Exploring</a>
      </div>
    </div>
  </div>

  <!-- Testimonials Section -->
  <div class="text-center mb-4">
    <h3 style="font-weight:bold; color:#185a9d;">What Our Customers Say</h3>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-4">
      <div class="testimonial-card d-flex align-items-center">
        <img src="assets/images/ruchi.jpg" alt="Ruchita D.">
        <div>
          <p class="mb-1" style="font-size:1.05rem;">"Amazing experience! Booking was super easy and the hotel was perfect."</p>
          <span style="font-weight:bold;">Ruchita D.</span>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="testimonial-card d-flex align-items-center">
        <img src="assets/images/user2.jpg" alt="Rahul M.">
        <div>
          <p class="mb-1" style="font-size:1.05rem;">"Best prices and great customer support. Will use again!"</p>
          <span style="font-weight:bold;">Nikhil l.</span>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>