<?php
session_start();
require_once 'includes/db.php'; // Use '../includes/db.php' if this file is in /admin

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle user deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    header("Location: manage_users.php");
    exit;
}

// Fetch all users
$result = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Users - Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8fafc; }
        .table-card { border-radius: 18px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); background: #fff; padding: 32px 24px; margin-top: 40px; }
        .table thead th { background: #f2f6fc; color: #2d3a4b; border-top: none; }
        .table-striped tbody tr:nth-of-type(odd) { background: #f8fafc; }
        .table-hover tbody tr:hover { background: #eaf4ff; }
        .action-btn { border-radius: 8px; font-weight: 500; }
        .action-btn i { margin-right: 4px; }
        .table-responsive { margin-bottom: 0; }
    </style>
</head>
<body>
<?php include 'navbar.php'; // Or your admin navbar ?>
<div class="container">
    <div class="table-card">
        <h2 class="mb-4" style="font-weight:600; color:#2d3a4b;"><i class="fa fa-users"></i> Manage Users</h2>
        <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Registered On</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php while($user = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($user['id']) ?></td>
                    <td><?= htmlspecialchars($user['name']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td><?= htmlspecialchars($user['phone']) ?></td>
                    <td><?= htmlspecialchars($user['created_at']) ?></td>
                    <td>
                        <a href="manage_users.php?delete=<?= $user['id'] ?>" class="btn btn-danger btn-sm action-btn" onclick="return confirm('Are you sure you want to delete this user?');"><i class="fa fa-trash"></i>Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        </div>
        <a href="dashboard.php" class="btn btn-secondary mt-3"><i class="fa fa-arrow-left"></i> Back to Dashboard</a>
    </div>
</div>
</body>
</html>