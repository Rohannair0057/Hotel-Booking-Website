<?php
session_start();
require_once 'includes/db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $error = "Email already registered.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $phone, $password);
        if ($stmt->execute()) {
            $_SESSION['user_id'] = $stmt->insert_id;
            header("Location: index.php");
            exit;
        } else {
            $error = "Registration failed. Try again.";
        }
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Register</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #ffaf7b 0%, #d76d77 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-card {
            max-width: 400px;
            margin: auto;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            background: #fff;
            padding: 2.5rem 2rem 2rem 2rem;
        }
        .register-card .fa-user-plus {
            font-size: 2.5rem;
            color: #d76d77;
            margin-bottom: 1rem;
        }
        .register-card .form-control {
            border-radius: 8px;
        }
        .register-card .btn-primary {
            border-radius: 8px;
            font-weight: bold;
            letter-spacing: 1px;
        }
    </style>
</head>
<body>
    <div class="register-card">
        <div class="text-center">
            <i class="fa fa-user-plus"></i>
            <h3 class="mb-4">User Register</h3>
        </div>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label><i class="fa fa-user"></i> Name</label>
                <input type="text" name="name" class="form-control" placeholder="Your name" required>
            </div>
            <div class="form-group">
                <label><i class="fa fa-envelope"></i> Email</label>
                <input type="email" name="email" class="form-control" placeholder="Your email" required>
            </div>
            <div class="form-group">
                <label><i class="fa fa-phone"></i> Phone</label>
                <input type="text" name="phone" class="form-control" placeholder="Your phone" required>
            </div>
            <div class="form-group">
                <label><i class="fa fa-lock"></i> Password</label>
                <input type="password" name="password" class="form-control" placeholder="Create a password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block mt-3">Register <i class="fa fa-user-plus"></i></button>
            <div class="text-center mt-3">
                <a href="login.php">Already have an account? Login</a>
            </div>
        </form>
    </div>
</body>
</html>