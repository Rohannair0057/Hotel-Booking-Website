<?php
session_start();
require_once 'includes/db.php';

$property_type = isset($_GET['property_type']) ? $_GET['property_type'] : '';
$location = isset($_GET['location']) ? $_GET['location'] : '';
$checkin = isset($_GET['checkin']) ? $_GET['checkin'] : '';
$checkout = isset($_GET['checkout']) ? $_GET['checkout'] : '';

// Base query to show all destinations if no filters are applied
$sql = "SELECT DISTINCT d.id, d.name, d.image, d.city, rt.type_name 
        FROM destinations d
        LEFT JOIN rooms r ON r.destination_id = d.id
        LEFT JOIN room_types rt ON r.room_type_id = rt.id
        WHERE d.type != 'city'";

$params = [];
$types = "";

// Add filters if they exist
if (!empty($property_type)) {
    $sql .= " AND rt.type_name = ?";
    $params[] = $property_type;
    $types .= "s";
}

if (!empty($location)) {
    $sql .= " AND (d.city LIKE ? OR d.name LIKE ?)";
    $params[] = "%$location%";
    $params[] = "%$location%";
    $types .= "ss";
}

$sql .= " GROUP BY d.id ORDER BY d.name";

try {
    if (!empty($params)) {
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Failed to prepare statement: " . $conn->error);
        }
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }

    if ($result === false) {
        throw new Exception("Query failed: " . $conn->error);
    }
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results - Travel Portal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8fafc; }
        .hero-section {
            background: linear-gradient(90deg, #4f8cff 0%, #38c6d9 100%);
            color: #fff;
            border-radius: 0 0 24px 24px;
            padding: 40px 0 30px 0;
            margin-bottom: 30px;
            text-align: center;
        }
        .property-card {
            transition: transform 0.2s, box-shadow 0.2s;
            border-radius: 18px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            overflow: hidden;
            background: #fff;
            animation: fadeIn 0.7s;
        }
        .property-card:hover {
            transform: translateY(-7px) scale(1.03);
            box-shadow: 0 8px 32px rgba(0,0,0,0.13);
        }
        .property-img {
            height: 200px;
            object-fit: cover;
            border-radius: 18px 18px 0 0;
        }
        .badge-type {
            background: #4f8cff;
            color: #fff;
            font-size: 0.95em;
            border-radius: 8px;
            margin-right: 6px;
        }
        .badge-city {
            background: #38c6d9;
            color: #fff;
            font-size: 0.95em;
            border-radius: 8px;
        }
        .filter-card {
            border-radius: 14px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            background: #fff;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        .no-results {
            text-align: center;
            padding: 40px 0 60px 0;
            color: #888;
        }
        .no-results i {
            font-size: 4em;
            color: #4f8cff;
            margin-bottom: 18px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="hero-section">
        <h1 class="mb-2" style="font-weight:700;">Find Your Perfect Stay</h1>
        <div style="font-size:1.2em;">
            <?php if ($location): ?>
                <span><i class="fa fa-map-marker-alt"></i> <?= htmlspecialchars($location) ?></span>
            <?php else: ?>
                <span><i class="fa fa-globe"></i> All Locations</span>
            <?php endif; ?>
            <?php if ($property_type): ?>
                <span class="ml-3"><i class="fa fa-building"></i> <?= htmlspecialchars($property_type) ?></span>
            <?php endif; ?>
            <?php if ($checkin): ?>
                <span class="ml-3"><i class="fa fa-calendar-check"></i> <?= htmlspecialchars($checkin) ?></span>
            <?php endif; ?>
            <?php if ($checkout): ?>
                <span class="ml-3"><i class="fa fa-calendar-minus"></i> <?= htmlspecialchars($checkout) ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="container mt-4">
        <!-- Search Filters -->
        <div class="row mb-4">
            <div class="col-12">
                <form action="search.php" method="GET" class="card p-3 filter-card">
                    <div class="row align-items-end">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label><i class="fa fa-map-marker-alt"></i> Location</label>
                                <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($location) ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label><i class="fa fa-building"></i> Property Type</label>
                                <select name="property_type" class="form-control">
                                    <option value="">All Types</option>
                                    <option value="Hotel" <?= $property_type == 'Hotel' ? 'selected' : '' ?>>Hotel</option>
                                    <option value="Villa" <?= $property_type == 'Villa' ? 'selected' : '' ?>>Villa</option>
                                    <option value="Apartment" <?= $property_type == 'Apartment' ? 'selected' : '' ?>>Apartment</option>
                                    <option value="Resort" <?= $property_type == 'Resort' ? 'selected' : '' ?>>Resort</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label><i class="fa fa-calendar-check"></i> Check-in</label>
                                <input type="date" name="checkin" class="form-control" value="<?= htmlspecialchars($checkin) ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label><i class="fa fa-calendar-minus"></i> Check-out</label>
                                <input type="date" name="checkout" class="form-control" value="<?= htmlspecialchars($checkout) ?>">
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Search Results -->
        <div class="row">
            <?php if (isset($error)): ?>
                <div class="col-12">
                    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                </div>
            <?php elseif (isset($result) && $result->num_rows > 0): ?>
                <?php while($property = $result->fetch_assoc()): ?>
                    <div class="col-md-4 mb-4 d-flex align-items-stretch">
                        <div class="card property-card h-100 w-100">
                            <img src="assets/images/<?= htmlspecialchars($property['image']) ?>" 
                                 class="card-img-top property-img" 
                                 alt="<?= htmlspecialchars($property['name']) ?>">
                            <div class="card-body">
                                <h5 class="card-title mb-1" style="font-weight:600; color:#2d3a4b;">
                                    <?= htmlspecialchars($property['name']) ?>
                                </h5>
                                <div class="mb-2">
                                    <?php if (!empty($property['type_name'])): ?>
                                        <span class="badge badge-type"><i class="fa fa-building"></i> <?= htmlspecialchars($property['type_name']) ?></span>
                                    <?php endif; ?>
                                    <span class="badge badge-city"><i class="fa fa-map-marker-alt"></i> <?= htmlspecialchars($property['city']) ?></span>
                                </div>
                                <a href="room_details.php?destination_id=<?= $property['id'] ?>" 
                                   class="btn btn-primary btn-block">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="no-results">
                        <i class="fa fa-search-location"></i>
                        <div style="font-size:1.3em; font-weight:500;">No properties found matching your search criteria.</div>
                        <div style="font-size:1em;">Try adjusting your filters or <a href="index.php">browse all properties</a>.</div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>