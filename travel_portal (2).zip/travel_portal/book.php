<?php
session_start();
require_once 'includes/db.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get room ID from URL or POST
$room_id = isset($_GET['room_id']) ? intval($_GET['room_id']) : (isset($_POST['room_id']) ? intval($_POST['room_id']) : 0);

// Fetch room details
$stmt = $conn->prepare("SELECT rooms.*, destinations.name AS destination_name, destinations.image AS destination_image FROM rooms JOIN destinations ON rooms.destination_id = destinations.id WHERE rooms.id = ?");
$stmt->bind_param("i", $room_id);
$stmt->execute();
$room = $stmt->get_result()->fetch_assoc();

if (!$room) {
    echo "<div class='container mt-5'><div class='alert alert-danger'>Room not found.</div></div>";
    exit;
}

// Default values
$checkin = $_POST['checkin'] ?? $_GET['checkin'] ?? '';
$checkout = $_POST['checkout'] ?? $_GET['checkout'] ?? '';
$nights = 1;
if ($checkin && $checkout) {
    $checkin_date = new DateTime($checkin);
    $checkout_date = new DateTime($checkout);
    $interval = $checkin_date->diff($checkout_date);
    $nights = $interval->days;
    if ($nights < 1) $nights = 1;
}
$price_per_night = $room['price'];
$total_price = $price_per_night * $nights;

// Handle booking form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payment_method'])) {
    $room_id = intval($_POST['room_id']);
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $adults = intval($_POST['adults']);
    $children = intval($_POST['children']);
    $id_type = $_POST['id_type'];
    $id_number = $_POST['id_number'];
    $user_id = $_SESSION['user_id'];

    // Calculate total price
    $nights = 1;
    if ($checkin && $checkout) {
        $checkin_date = new DateTime($checkin);
        $checkout_date = new DateTime($checkout);
        $interval = $checkin_date->diff($checkout_date);
        $nights = $interval->days;
        if ($nights < 1) $nights = 1;
    }
    $price_per_night = $room['price'];
    $total_price = $price_per_night * $nights;

    if ($_POST['payment_method'] === 'pay_now') {
        // Store in session and redirect to payment
        $_SESSION['booking_data'] = [
            'room_id' => $room_id,
            'checkin' => $checkin,
            'checkout' => $checkout,
            'adults' => $adults,
            'children' => $children,
            'id_type' => $id_type,
            'id_number' => $id_number,
            'total_price' => $total_price
        ];
        header("Location: payment.php");
        exit;
    } else {
        // Pay at property: Insert booking directly
        $stmt = $conn->prepare("INSERT INTO bookings (user_id, room_id, check_in, check_out, adults, children, id_type, id_number, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')");
        $stmt->bind_param("iississs", $user_id, $room_id, $checkin, $checkout, $adults, $children, $id_type, $id_number);
        $stmt->execute();
        header("Location: order_confirmed.php");
        exit;
    }
}

// Get the first image from the comma-separated list
$imageList = explode(',', $room['image']);
$firstImage = trim($imageList[0]);
$imagePath = 'assets/images/' . ($firstImage ? htmlspecialchars($firstImage) : 'default-room.jpg');
if (!file_exists($imagePath) || empty($firstImage)) {
    $imagePath = 'assets/images/default-room.jpg';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Book Room - Travel Portal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { background: #f8fafc; }
        .booking-card { max-width: 700px; margin: 40px auto; border-radius: 18px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
        .room-img { width: 100%; height: 220px; object-fit: cover; border-radius: 18px 18px 0 0; }
        .price-summary { background: linear-gradient(90deg, #4f8cff 0%, #38c6d9 100%); color: #fff; border-radius: 12px; padding: 18px; margin-bottom: 20px; }
        .modal-content { border-radius: 18px; }
        .payment-card { border-radius: 14px; border: 1px solid #e3e3e3; }
        .payment-card.selected { border: 2px solid #4f8cff; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="booking-card bg-white">
            <?php if (!empty($room['image'])): ?>
                <img src="<?= $imagePath ?>" class="room-img" alt="Room Image">
            <?php else: ?>
                <img src="assets/images/default-room.jpg" class="room-img" alt="Room Image">
            <?php endif; ?>
            <div class="p-4">
                <h3 class="mb-1" style="font-weight:600; color:#2d3a4b;">
                    <?= htmlspecialchars($room['name']) ?> <span class="badge badge-info" style="font-size:0.7em;">in <?= htmlspecialchars($room['destination_name']) ?></span>
                </h3>
                <div class="price-summary d-flex align-items-center justify-content-between">
                    <div>
                        <div style="font-size:1.2em;">₹<?= number_format($price_per_night) ?> <span style="font-size:0.8em;">/ night</span></div>
                        <div style="font-size:0.95em;" class="nights">for <?= $nights ?> night<?= $nights > 1 ? 's' : '' ?></div>
                    </div>
                    <div class="text-right">
                        <div style="font-size:1.5em; font-weight:700;" class="total-price">₹<?= number_format($total_price) ?></div>
                        <div style="font-size:0.9em;">Total incl. taxes</div>
                    </div>
                </div>
                <form id="bookingForm" method="post">
                    <input type="hidden" name="room_id" value="<?= $room['id'] ?>">
                    <input type="hidden" name="total_price" value="<?= $total_price ?>">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Check-in Date</label>
                            <input type="date" name="checkin" class="form-control" value="<?= htmlspecialchars($checkin) ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Check-out Date</label>
                            <input type="date" name="checkout" class="form-control" value="<?= htmlspecialchars($checkout) ?>" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Number of Adults</label>
                            <input type="number" name="adults" class="form-control" min="1" max="10" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Number of Children</label>
                            <input type="number" name="children" class="form-control" min="0" max="10" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Identity Type</label>
                            <select name="id_type" class="form-control" required>
                                <option value="">Select</option>
                                <option value="Aadhar">Aadhar</option>
                                <option value="PAN">PAN</option>
                                <option value="License">License</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Identity Number</label>
                            <input type="text" name="id_number" class="form-control" required>
                        </div>
                    </div>
                    <button type="button" class="btn btn-primary btn-block mt-3" data-toggle="modal" data-target="#paymentOptionsModal">Proceed to Payment</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Payment Options Modal -->
    <div class="modal fade" id="paymentOptionsModal" tabindex="-1" aria-labelledby="paymentOptionsLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content p-4">
          <div class="modal-header border-0">
            <h5 class="modal-title" id="paymentOptionsLabel">Your payment options</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body d-flex flex-column flex-md-row justify-content-between">
            <!-- Pay at property -->
            <div class="payment-card flex-fill mx-2 mb-3 mb-md-0 p-4 shadow-sm">
              <h6 class="fw-bold">Pay when you stay</h6>
              <ul>
                <li>Pay the property directly in their preferred currency (INR)</li>
              </ul>
              <div class="my-3">
                <span class="fw-bold fs-4 modal-total-price">₹<?= number_format($total_price) ?></span>
                <div class="text-muted" style="font-size: 0.9em;">includes taxes & fees</div>
              </div>
              <form method="post" action="order_confirmed.php" style="margin:0;" id="payAtPropertyForm">
                <input type="hidden" name="room_id" value="<?= $room['id'] ?>">
                <input type="hidden" name="checkin" value="">
                <input type="hidden" name="checkout" value="">
                <input type="hidden" name="adults" value="">
                <input type="hidden" name="children" value="">
                <input type="hidden" name="id_type" value="">
                <input type="hidden" name="id_number" value="">
                <input type="hidden" name="payment_method" value="pay_at_property">
                <input type="hidden" name="total_price" value="<?= $total_price ?>">
                <button type="submit" class="btn btn-outline-primary w-100">Pay at property</button>
              </form>
            </div>
            <!-- Pay now -->
            <div class="payment-card flex-fill mx-2 p-4 shadow-sm">
              <h6 class="fw-bold">Pay now</h6>
              <ul>
                <li>We will process your payment in your local currency</li>
                <li>More ways to pay: use debit/credit card</li>
                <li>You can use a valid coupon</li>
              </ul>
              <div class="my-3">
                <span class="fw-bold fs-4 modal-total-price">₹<?= number_format($total_price) ?></span>
                <div class="text-muted" style="font-size: 0.9em;">includes taxes & fees</div>
              </div>
              <form method="post" style="margin:0;" id="payNowForm">
                <input type="hidden" name="room_id" value="<?= $room['id'] ?>">
                <input type="hidden" name="checkin" value="">
                <input type="hidden" name="checkout" value="">
                <input type="hidden" name="adults" value="">
                <input type="hidden" name="children" value="">
                <input type="hidden" name="id_type" value="">
                <input type="hidden" name="id_number" value="">
                <input type="hidden" name="payment_method" value="pay_now">
                <input type="hidden" name="total_price" value="<?= $total_price ?>">
                <button type="submit" class="btn btn-primary w-100">Pay now</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Function to calculate nights and update price
    function updatePrice() {
        var checkin = $('input[name="checkin"]').val();
        var checkout = $('input[name="checkout"]').val();
        var pricePerNight = <?= $price_per_night ?>; // Get price from PHP
        
        if (checkin && checkout) {
            var start = new Date(checkin);
            var end = new Date(checkout);
            var nights = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
            if (nights < 1) nights = 1;
            
            var totalPrice = nights * pricePerNight;
            
            // Update price display
            $('.price-summary .nights').text(nights + ' night' + (nights > 1 ? 's' : ''));
            $('.price-summary .total-price').text('₹' + totalPrice.toLocaleString());
            
            // Update modal price display
            $('.modal-total-price').text('₹' + totalPrice.toLocaleString());
            // Update hidden total_price in both modal forms
            $('#paymentOptionsModal form input[name="total_price"]').val(totalPrice);
            $('input[name="total_price"]').val(totalPrice);
        }
    }

    // Update price when dates change
    $('input[name="checkin"], input[name="checkout"]').on('change', updatePrice);

    // Also update price when the modal is shown
    $('#paymentOptionsModal').on('show.bs.modal', function () {
        updatePrice();

        // Get values from the main form
        var checkin = $('input[name="checkin"]').val();
        var checkout = $('input[name="checkout"]').val();
        var adults = $('input[name="adults"]').val();
        var children = $('input[name="children"]').val();
        var id_type = $('select[name="id_type"]').val();
        var id_number = $('input[name="id_number"]').val();

        // Set them in the hidden fields of the modal forms
        $('#payNowForm input[name="checkin"]').val(checkin);
        $('#payNowForm input[name="checkout"]').val(checkout);
        $('#payNowForm input[name="adults"]').val(adults);
        $('#payNowForm input[name="children"]').val(children);
        $('#payNowForm input[name="id_type"]').val(id_type);
        $('#payNowForm input[name="id_number"]').val(id_number);

        // Do the same for the pay-at-property form if needed
        $('#payAtPropertyForm input[name="checkin"]').val(checkin);
        $('#payAtPropertyForm input[name="checkout"]').val(checkout);
        $('#payAtPropertyForm input[name="adults"]').val(adults);
        $('#payAtPropertyForm input[name="children"]').val(children);
        $('#payAtPropertyForm input[name="id_type"]').val(id_type);
        $('#payAtPropertyForm input[name="id_number"]').val(id_number);
    });

    // Handle Pay Now button click
    $('#payNowBtn').on('click', function(e) {
        e.preventDefault();
        
        // Validate form data
        var checkin = $('input[name="checkin"]').val();
        var checkout = $('input[name="checkout"]').val();
        var adults = $('input[name="adults"]').val();
        var idType = $('select[name="id_type"]').val();
        var idNumber = $('input[name="id_number"]').val();
        
        var errors = [];
        
        if (!checkin) errors.push("Please select check-in date");
        if (!checkout) errors.push("Please select check-out date");
        if (!adults || adults < 1) errors.push("At least one adult is required");
        if (!idType) errors.push("Please select ID type");
        if (!idNumber) errors.push("Please enter ID number");
        
        if (errors.length > 0) {
            alert("Please correct the following errors:\n" + errors.join("\n"));
            return;
        }
        
        // Store booking data in session
        $.ajax({
            url: 'store_booking_data.php',
            method: 'POST',
            data: {
                room_id: $('input[name="room_id"]').val(),
                checkin: checkin,
                checkout: checkout,
                adults: adults,
                children: $('input[name="children"]').val(),
                id_type: idType,
                id_number: idNumber,
                total_price: $('input[name="total_price"]').val()
            },
            success: function(response) {
                try {
                    var data = JSON.parse(response);
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    }
                } catch (e) {
                    console.error('Error parsing response:', e);
                    alert('An error occurred. Please try again.');
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
            }
        });
    });
    </script>
</body>
</html>