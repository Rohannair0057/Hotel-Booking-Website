<?php
session_start();
require_once 'includes/db.php';
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$id = intval($_GET['id']);
$action = $_GET['action'];

if ($action == 'confirm') {
    $conn->query("UPDATE bookings SET status='Confirmed' WHERE id=$id");
} elseif ($action == 'cancel') {
    $conn->query("UPDATE bookings SET status='Cancelled' WHERE id=$id");
}
header("Location: manage_bookings.php");
exit;
?>