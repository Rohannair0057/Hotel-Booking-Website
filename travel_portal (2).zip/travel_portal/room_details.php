<?php
session_start();
require_once 'includes/db.php';

$destination_id = isset($_GET['destination_id']) ? intval($_GET['destination_id']) : 0;

// Fetch hotel details
$stmt = $conn->prepare("SELECT * FROM destinations WHERE id = ?");
$stmt->bind_param("i", $destination_id);
$stmt->execute();
$hotel = $stmt->get_result()->fetch_assoc();

if (!$hotel) {
    echo "<div class='container mt-5'><div class='alert alert-danger'>Hotel not found.</div></div>";
    exit;
}

// Fetch all rooms for this hotel
$stmt = $conn->prepare("SELECT rooms.*, room_types.type_name 
                        FROM rooms 
                        JOIN room_types ON rooms.room_type_id = room_types.id 
                        WHERE rooms.destination_id = ?");
$stmt->bind_param("i", $destination_id);
$stmt->execute();
$rooms = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($hotel['name']) ?> - Available Rooms</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .room-slider {
            position: relative;
            height: 250px;
            overflow: hidden;
        }
        .room-slider img {
            height: 250px;
            object-fit: cover;
        }
        .carousel-control-prev, .carousel-control-next {
            width: 40px;
            height: 40px;
            background: rgba(0,0,0,0.5);
            border-radius: 50%;
            top: 50%;
            transform: translateY(-50%);
        }
        .carousel-control-prev {
            left: 10px;
        }
        .carousel-control-next {
            right: 10px;
        }
        .room-card {
            transition: transform 0.2s;
        }
        .room-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <!-- Hotel Header -->
    <div id="hotelCarousel" class="carousel slide mb-4" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="assets/images/<?= htmlspecialchars($hotel['image']) ?>" class="d-block w-100" style="height: 400px; object-fit: cover;" alt="<?= htmlspecialchars($hotel['name']) ?>">
                <div class="carousel-caption">
                    <h2><?= htmlspecialchars($hotel['name']) ?></h2>
                    <p class="lead"><?= htmlspecialchars($hotel['city']) ?></p>
                </div>
            </div>
        </div>
    </div>

    <hr>
    <h4 class="mb-4">Available Rooms</h4>
    
    <div class="row">
        <?php if ($rooms->num_rows > 0): ?>
            <?php 
            $room_counter = 0;
            while($room = $rooms->fetch_assoc()): 
                $room_images = explode(',', $room['image']); // Assuming images are comma-separated
            ?>
                <div class="col-md-4 mb-4">
                    <div class="card room-card h-100">
                        <!-- Room Image Slider -->
                        <div id="roomCarousel<?= $room['id'] ?>" class="carousel slide room-slider" data-ride="carousel">
                            <div class="carousel-inner">
                                <?php 
                                foreach($room_images as $index => $image): 
                                    $image = trim($image);
                                ?>
                                    <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                                        <img src="assets/images/<?= htmlspecialchars($image) ?>" 
                                             class="d-block w-100" 
                                             alt="<?= htmlspecialchars($room['name']) ?>">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <?php if(count($room_images) > 1): ?>
                                <a class="carousel-control-prev" href="#roomCarousel<?= $room['id'] ?>" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                </a>
                                <a class="carousel-control-next" href="#roomCarousel<?= $room['id'] ?>" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                </a>
                            <?php endif; ?>
                        </div>

                        <div class="card-body">
                            <h5 class="card-title">
                                <?= htmlspecialchars($room['name']) ?>
                                <span class="badge badge-info"><?= htmlspecialchars($room['type_name']) ?></span>
                            </h5>
                            <p class="card-text">
                                <i class="fas fa-concierge-bell text-primary"></i> 
                                <strong>Facilities:</strong><br>
                                <?= htmlspecialchars($room['facilities']) ?>
                            </p>
                            <p class="card-text">
                                <i class="fas fa-rupee-sign text-success"></i>
                                <strong>Price:</strong> 
                                ₹<?= number_format($room['price']) ?> / night
                            </p>
                            <a href="book.php?room_id=<?= $room['id'] ?>" class="btn btn-primary btn-block">
                                <i class="fas fa-calendar-check"></i> Book Now
                            </a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    No rooms available for this hotel.
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
// Initialize all carousels
$('.carousel').carousel({
    interval: 3000 // Change slides every 3 seconds
});
</script>
</body>
</html>