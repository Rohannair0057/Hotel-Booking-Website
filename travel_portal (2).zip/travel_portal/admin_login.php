<?php
session_start();
require_once 'includes/db.php'; // Use '../includes/db.php' if in /admin

if (isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT id, password FROM admin WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $db_password);
        $stmt->fetch();
        if ($password === $db_password) { // plain text check for demo
            $_SESSION['admin_id'] = $id;
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid credentials.";
        }
    } else {
        $error = "Invalid credentials.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #007bff 0%, #6a11cb 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            max-width: 400px;
            margin: auto;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            background: #fff;
            padding: 2.5rem 2rem 2rem 2rem;
        }
        .login-card .fa-user-shield {
            font-size: 2.5rem;
            color: #007bff;
            margin-bottom: 1rem;
        }
        .login-card .form-control {
            border-radius: 8px;
        }
        .login-card .btn-primary {
            border-radius: 8px;
            font-weight: bold;
            letter-spacing: 1px;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="text-center">
            <i class="fa fa-user-shield"></i>
            <h3 class="mb-4">Admin Login</h3>
        </div>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label><i class="fa fa-envelope"></i> Username (Email)</label>
                <input type="text" name="username" class="form-control" placeholder="rohan@gmail.com" required>
            </div>
            <div class="form-group">
                <label><i class="fa fa-lock"></i> Password</label>
                <input type="password" name="password" class="form-control" placeholder="Your password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block mt-3">Login <i class="fa fa-arrow-right"></i></button>
        </form>
    </div>
</body>
</html>