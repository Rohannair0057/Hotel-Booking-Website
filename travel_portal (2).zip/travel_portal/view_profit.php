<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Get selected month/year
$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// Query: profit per room
$sql = "SELECT 
            d.name AS hotel_name, 
            r.name AS room_name, 
            COUNT(b.id) AS total_bookings, 
            SUM(p.amount) AS total_revenue, 
            SUM(p.amount * 0.15) AS platform_fee, 
            SUM(p.amount - (p.amount * 0.15)) AS net_profit
        FROM rooms r
        JOIN destinations d ON r.destination_id = d.id
        LEFT JOIN bookings b ON r.id = b.room_id AND MONTH(b.check_in) = ? AND YEAR(b.check_in) = ?
        LEFT JOIN payments p ON b.id = p.booking_id
        GROUP BY d.id, d.name, r.id, r.name
        ORDER BY net_profit DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $month, $year);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Profits</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: #fff;
            padding-top: 30px;
        }
        .sidebar a {
            color: #fff;
            display: block;
            padding: 12px 20px;
            margin-bottom: 8px;
            border-radius: 4px;
            text-decoration: none;
        }
        .sidebar a.active, .sidebar a:hover {
            background: #495057;
            color: #ffc107;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 sidebar">
            <h4 class="text-center mb-4"><i class="fa fa-user-shield"></i> Admin</h4>
            <a href="dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a>
            <a href="manage_bookings.php"><i class="fa fa-calendar-check"></i> Manage Bookings</a>
            <a href="manage_users.php"><i class="fa fa-users"></i> Manage Users</a>
            <a href="manage_rooms.php"><i class="fa fa-bed"></i> Manage Rooms</a>
            <a href="view_profit.php" class="active" style="color: #ffc107; font-weight: bold;"><i class="fa fa-chart-line"></i> View Profits</a>
            <a href="add_room.php"><i class="fa fa-plus"></i> Add Room</a>
            <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
        </nav>
        <!-- Main Content -->
        <main class="col-md-10 py-4">
            <h2 class="mb-4">Room Profit Analysis</h2>
            <form method="get" class="form-inline mb-4">
                <label class="mr-2">Month:</label>
                <select name="month" class="form-control mr-2">
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option value="<?= $m ?>" <?= ($m == $month) ? 'selected' : '' ?>><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                    <?php endfor; ?>
                </select>
                <label class="mr-2">Year:</label>
                <select name="year" class="form-control mr-2">
                    <?php $curYear = date('Y');
                    for ($y = $curYear - 2; $y <= $curYear + 1; $y++): ?>
                        <option value="<?= $y ?>" <?= ($y == $year) ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endfor; ?>
                </select>
                <button type="submit" class="btn btn-primary">View</button>
            </form>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Hotel Name</th>
                                    <th>Room Name</th>
                                    <th>Total Bookings</th>
                                    <th>Total Revenue</th>
                                    <th>Platform Fee (15%)</th>
                                    <th>Net Profit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['hotel_name']) ?></td>
                                    <td><?= htmlspecialchars($row['room_name']) ?></td>
                                    <td><?= $row['total_bookings'] ?></td>
                                    <td>₹<?= number_format($row['total_revenue'], 2) ?></td>
                                    <td>₹<?= number_format($row['platform_fee'], 2) ?></td>
                                    <td>₹<?= number_format($row['net_profit'], 2) ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html> 