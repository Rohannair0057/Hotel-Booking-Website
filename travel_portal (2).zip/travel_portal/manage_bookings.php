<?php
session_start();
require_once 'includes/db.php'; // Use '../includes/db.php' if in /admin

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$sql = "SELECT bookings.*, users.name as user_name, users.email as user_email, rooms.name as room_name, rooms.image as room_image, destinations.name as hotel_name, destinations.image as hotel_image, payments.payment_method, payments.transaction_id 
        FROM bookings
        JOIN users ON bookings.user_id = users.id
        JOIN rooms ON bookings.room_id = rooms.id
        JOIN destinations ON rooms.destination_id = destinations.id
        LEFT JOIN payments ON bookings.id = payments.booking_id
        ORDER BY bookings.created_at DESC";
$result = $conn->query($sql);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'], $_POST['action'])) {
    $booking_id = intval($_POST['booking_id']);
    $action = $_POST['action'] === 'accept' ? 'Confirmed' : 'Rejected';
    $stmt = $conn->prepare("UPDATE bookings SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $action, $booking_id);
    $stmt->execute();
    // Optionally, show a success message or redirect
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Bookings - Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .hotel-img-thumb {
            width: 60px;
            height: 40px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.10);
            border: 2px solid #e3e3e3;
        }
        .table thead th {
            background: #f4f8fb;
            color: #2d3a4b;
            font-weight: 600;
            border-bottom: 2px solid #e3e3e3;
        }
        .table-hover tbody tr:hover {
            background: #eaf6ff;
            transition: background 0.2s;
        }
        .rounded-pill {
            border-radius: 50rem!important;
        }
        .px-3 { padding-left: 1rem!important; padding-right: 1rem!important; }
        .mr-2 { margin-right: 0.5rem!important; }
        .card.shadow {
            border-radius: 18px;
            box-shadow: 0 4px 18px rgba(67,206,162,0.10);
            margin-bottom: 32px;
            background: #fff;
            border: none;
        }
        .badge-status {
            font-size: 0.95em;
            padding: 0.5em 1em;
            border-radius: 12px;
        }
        .badge-pending { background: #ffc107; color: #fff; }
        .badge-confirmed { background: #38c172; color: #fff; }
        .badge-rejected, .badge-cancelled { background: #e3342f; color: #fff; }
        .badge-secondary { background: #b0b0b0; color: #fff; }
        .action-btns .btn { min-width: 80px; }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-5">
    <h2 class="mb-4"><i class="fa fa-calendar-check"></i> Manage Bookings</h2>
    <div class="mb-3">
        <input type="text" class="form-control" id="bookingSearch" placeholder="Search by guest, hotel, room, or status...">
    </div>
    <script>
    document.getElementById('bookingSearch').addEventListener('keyup', function() {
        var value = this.value.toLowerCase();
        var rows = document.querySelectorAll('table tbody tr');
        rows.forEach(function(row) {
            row.style.display = row.textContent.toLowerCase().includes(value) ? '' : 'none';
        });
    });
    </script>
    <div class="card shadow mb-5">
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Hotel Image</th>
                        <th>Hotel</th>
                        <th>Room</th>
                        <th>Guest</th>
                        <th>Check-in</th>
                        <th>Check-out</th>
                        <th>Status</th>
                        <th>Payment Method</th>
                        <th>Transaction ID</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <?php if ($row['hotel_image']): ?>
                                <img src="assets/images/<?= htmlspecialchars($row['hotel_image']) ?>" alt="Hotel" class="hotel-img-thumb">
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($row['hotel_name']) ?></td>
                        <td><?= htmlspecialchars($row['room_name']) ?></td>
                        <td><?= htmlspecialchars($row['user_name']) ?></td>
                        <td><?= htmlspecialchars($row['check_in']) ?></td>
                        <td><?= htmlspecialchars($row['check_out']) ?></td>
                        <td>
                            <?php
                                $status = strtolower($row['status']);
                                if ($status === 'pending') {
                                    echo '<span class="badge badge-warning">Pending</span>';
                                } elseif ($status === 'confirmed') {
                                    echo '<span class="badge badge-success">Confirmed</span>';
                                } elseif ($status === 'rejected' || $status === 'cancelled') {
                                    echo '<span class="badge badge-danger">'.ucfirst($status).'</span>';
                                } else {
                                    echo '<span class="badge badge-secondary">'.ucfirst($status).'</span>';
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                if ($row['payment_method']) {
                                    echo htmlspecialchars(ucfirst($row['payment_method']));
                                } else {
                                    echo 'Pay at Property';
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                if ($row['payment_method'] && $row['transaction_id']) {
                                    echo htmlspecialchars($row['transaction_id']);
                                } else {
                                    echo 'N/A';
                                }
                            ?>
                        </td>
                        <td>
                            <?php if ($status === 'pending'): ?>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="booking_id" value="<?= $row['id'] ?>">
                                    <button type="submit" name="action" value="accept" class="btn btn-success btn-sm rounded-pill px-3 mr-2">Accept</button>
                                    <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm rounded-pill px-3">Reject</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
    <a href="dashboard.php" class="btn btn-secondary mt-4"><i class="fa fa-arrow-left"></i> Back to Dashboard</a>
</div>
</body>
</html>