<?php
session_start();
require_once 'includes/db.php'; // Use '../includes/db.php' if this file is in /admin

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Fetch all hotels (destinations) and room types for dropdowns
$hotels = $conn->query("SELECT id, name FROM destinations ORDER BY name");
$room_types = $conn->query("SELECT id, type_name FROM room_types ORDER BY type_name");

$success = "";
$error = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_type_id = intval($_POST['room_type_id']);
    $destination_id = intval($_POST['destination_id']);
    $name = $_POST['name'];
    $description = $_POST['description'];
    $facilities = $_POST['facilities'];
    $price = floatval($_POST['price']);
    $total_rooms = intval($_POST['total_rooms']);
    $available_rooms = $total_rooms;

    // Handle image upload
    $image = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], "assets/images/" . $image); // Use "../assets/images/" if in /admin
    }

    $stmt = $conn->prepare("INSERT INTO rooms (room_type_id, destination_id, name, description, facilities, price, image, total_rooms, available_rooms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iissssdii", $room_type_id, $destination_id, $name, $description, $facilities, $price, $image, $total_rooms, $available_rooms);
    if ($stmt->execute()) {
        $success = "Room added successfully!";
    } else {
        $error = "Failed to add room.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Room - Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-5">
    <h2>Add New Room</h2>
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Hotel/Place</label>
            <select name="destination_id" class="form-control" required>
                <option value="">Select Hotel</option>
                <?php
                // Reset pointer if needed
                $hotels->data_seek(0);
                while($hotel = $hotels->fetch_assoc()): ?>
                    <option value="<?= $hotel['id'] ?>"><?= htmlspecialchars($hotel['name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Room Type</label>
            <select name="room_type_id" class="form-control" required>
                <option value="">Select Type</option>
                <?php
                $room_types->data_seek(0);
                while($type = $room_types->fetch_assoc()): ?>
                    <option value="<?= $type['id'] ?>"><?= htmlspecialchars($type['type_name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Room Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea name="description" class="form-control" required></textarea>
        </div>
        <div class="form-group">
            <label>Facilities</label>
            <input type="text" name="facilities" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Price per Night</label>
            <input type="number" name="price" class="form-control" step="0.01" required>
        </div>
        <div class="form-group">
            <label>Total Rooms</label>
            <input type="number" name="total_rooms" class="form-control" min="1" required>
        </div>
        <div class="form-group">
            <label>Room Image</label>
            <input type="file" name="image" class="form-control-file" required>
        </div>
        <button type="submit" class="btn btn-success">Add Room</button>
        <a href="manage_rooms.php" class="btn btn-secondary">Back to Manage Rooms</a>
    </form>
</div>
</body>
</html>