<?php
session_start();
require_once 'includes/db.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch all bookings for this user, joining rooms and destinations
$sql = "SELECT 
            bookings.*, 
            rooms.name AS room_name, 
            rooms.image AS room_image, 
            destinations.name AS hotel_name, 
            destinations.image AS hotel_image 
        FROM bookings
        JOIN rooms ON bookings.room_id = rooms.id
        JOIN destinations ON rooms.destination_id = destinations.id
        WHERE bookings.user_id = ?
        ORDER BY bookings.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Bookings - Travel Portal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8fafc; }
        .booking-card { border-radius: 18px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); transition: box-shadow 0.2s; }
        .booking-card:hover { box-shadow: 0 8px 32px rgba(0,0,0,0.13); }
        .hotel-img { width: 100%; height: 120px; object-fit: cover; border-radius: 18px 18px 0 0; }
        .room-img { width: 60px; height: 60px; object-fit: cover; border-radius: 12px; position: absolute; top: 90px; left: 20px; border: 3px solid #fff; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .status-badge { font-size: 0.95em; padding: 0.4em 1em; border-radius: 8px; }
        .status-pending { background: #ffc107; color: #fff; }
        .status-confirmed { background: #38c172; color: #fff; }
        .status-cancelled { background: #e3342f; color: #fff; }
        .status-secondary { background: #b0b0b0; color: #fff; }
        .booking-details i { color: #4f8cff; margin-right: 6px; }
        .cancel-btn { background: #ff4d4f; color: #fff; border-radius: 8px; font-weight: 500; }
        .cancel-btn:hover { background: #d9363e; color: #fff; }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-5">
    <h2 class="mb-4" style="font-weight:600; color:#2d3a4b;">My Bookings</h2>
    <?php if ($result->num_rows > 0): ?>
        <div class="row">
            <?php while($booking = $result->fetch_assoc()): ?>
                <div class="col-md-6 mb-4">
                    <div class="card booking-card h-100 position-relative">
                        <img src="assets/images/<?= htmlspecialchars($booking['hotel_image']) ?>" class="hotel-img" alt="<?= htmlspecialchars($booking['hotel_name']) ?>">
                        <?php
                        $roomImage = $booking['room_image'];
                        if (strpos($roomImage, ',') !== false) {
                            $roomImage = explode(',', $roomImage)[0];
                        }
                        ?>
                        <img src="assets/images/<?= htmlspecialchars($roomImage) ?>" class="room-img" alt="<?= htmlspecialchars($booking['room_name']) ?>">
                        <div class="card-body pt-4">
                            <h5 class="card-title mb-1" style="font-weight:600; color:#2d3a4b;">
                                <i class="fa fa-hotel"></i> <?= htmlspecialchars($booking['hotel_name']) ?>
                            </h5>
                            <div class="mb-2">
                                <?php if ($booking['status'] === 'Pending'): ?>
                                    <span class="badge status-badge status-pending">Pending</span>
                                <?php elseif ($booking['status'] === 'Confirmed'): ?>
                                    <span class="badge status-badge status-confirmed">Confirmed</span>
                                <?php elseif ($booking['status'] === 'Rejected'): ?>
                                    <span class="badge status-badge status-cancelled">Rejected</span>
                                <?php elseif ($booking['status'] === 'Cancelled'): ?>
                                    <span class="badge status-badge status-cancelled">Cancelled</span>
                                <?php else: ?>
                                    <span class="badge status-badge status-secondary"><?= htmlspecialchars($booking['status']) ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="booking-details mb-2">
                                <div><i class="fa fa-bed"></i> <b>Room:</b> <?= htmlspecialchars($booking['room_name']) ?></div>
                                <div>
                                    <i class="fa fa-calendar-check"></i> <b>Check-in:</b>
                                    <?= ($booking['check_in'] && $booking['check_in'] != '0000-00-00') ? date('d M Y', strtotime($booking['check_in'])) : 'N/A' ?>
                                </div>
                                <div>
                                    <i class="fa fa-calendar-minus"></i> <b>Check-out:</b>
                                    <?= ($booking['check_out'] && $booking['check_out'] != '0000-00-00') ? date('d M Y', strtotime($booking['check_out'])) : 'N/A' ?>
                                </div>
                                <div><i class="fa fa-clock"></i> <b>Booked on:</b> <?= date('d M Y H:i', strtotime($booking['created_at'])) ?></div>
                            </div>
                            <?php if ($booking['status'] !== 'Cancelled'): ?>
                                <form method="post" action="cancel_booking.php" onsubmit="return confirm('Are you sure you want to cancel this booking?');">
                                    <input type="hidden" name="booking_id" value="<?= $booking['id'] ?>">
                                    <button type="submit" class="btn cancel-btn btn-sm mt-2">Cancel Booking</button>
                                </form>
                            <?php else: ?>
                                <span class="badge badge-secondary mt-2">Cancelled</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">You have no bookings yet.</div>
    <?php endif; ?>
    <a href="index.php" class="btn btn-primary mb-5 justify-content-center">Back to Home</a>
</div>
</body>
</html>