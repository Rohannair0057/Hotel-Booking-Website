<?php
include 'includes/config.php';
include 'navbar.php';

// Get all hotels and apartments from Maharashtra cities
$cities = ['Shirdi', 'Nagar', 'Nashik', 'Pune'];
$placeholders = str_repeat('?,', count($cities) - 1) . '?';
$sql = "SELECT d.*, rt.type_name 
        FROM destinations d 
        JOIN room_types rt ON d.type = rt.id 
        WHERE d.city IN ($placeholders) 
        ORDER BY d.city, d.name";
$stmt = $conn->prepare($sql);
$stmt->execute($cities);
$hotels = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maharashtra Hotels - Travel Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Hotels in Maharashtra</h1>
        
        <?php
        $current_city = '';
        foreach ($hotels as $hotel) {
            if ($current_city != $hotel['city']) {
                if ($current_city != '') {
                    echo '</div></div>'; // Close previous city section
                }
                $current_city = $hotel['city'];
                echo '<div class="city-section mb-5">';
                echo '<h2 class="mb-4">' . htmlspecialchars($current_city) . '</h2>';
                echo '<div class="row">';
            }
            ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="img/<?php echo htmlspecialchars($hotel['image']); ?>" 
                         class="card-img-top" 
                         alt="<?php echo htmlspecialchars($hotel['name']); ?>"
                         style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($hotel['name']); ?></h5>
                        <p class="card-text">
                            <span class="badge bg-primary"><?php echo htmlspecialchars($hotel['type_name']); ?></span>
                        </p>
                        <a href="room_details.php?id=<?php echo $hotel['id']; ?>" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            </div>
            <?php
        }
        if ($current_city != '') {
            echo '</div></div>'; // Close last city section
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 