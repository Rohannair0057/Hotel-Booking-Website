<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Prefer POST data (from payment form), fallback to session
$room_id = $_POST['room_id'] ?? ($_SESSION['booking_data']['room_id'] ?? null);
$checkin = $_POST['checkin'] ?? ($_SESSION['booking_data']['checkin'] ?? null);
$checkout = $_POST['checkout'] ?? ($_SESSION['booking_data']['checkout'] ?? null);
$adults = $_POST['adults'] ?? ($_SESSION['booking_data']['adults'] ?? 0);
$children = $_POST['children'] ?? ($_SESSION['booking_data']['children'] ?? 0);
$id_type = $_POST['id_type'] ?? ($_SESSION['booking_data']['id_type'] ?? '');
$id_number = $_POST['id_number'] ?? ($_SESSION['booking_data']['id_number'] ?? '');
$total_price = $_POST['total_price'] ?? ($_SESSION['booking_data']['total_price'] ?? 0);
$payment_method = $_POST['payment_method'] ?? '';
$utr_no = $_POST['utr_no'] ?? '';
$transaction_id = $_POST['transaction_id'] ?? '';

// Get card details if payment method is card
$card_number = '';
$card_name = '';
$card_expiry = '';
if ($payment_method === 'card') {
    $card_number = $_POST['card_number'] ?? '';
    $card_name = $_POST['card_name'] ?? '';
    $card_expiry = $_POST['card_expiry'] ?? '';
    
    // Mask card number for security (only store last 4 digits)
    $card_number = 'XXXX-XXXX-XXXX-' . substr(preg_replace('/[^0-9]/', '', $card_number), -4);
}

// Start transaction
$conn->begin_transaction();

try {
    // Insert booking
    $stmt = $conn->prepare("INSERT INTO bookings (user_id, room_id, check_in, check_out, adults, children, id_type, id_number, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')");
    $stmt->bind_param("iississs", $user_id, $room_id, $checkin, $checkout, $adults, $children, $id_type, $id_number);
    $stmt->execute();
    $booking_id = $conn->insert_id;

    // Insert payment record with transaction ID and card details
    $stmt = $conn->prepare("INSERT INTO payments (booking_id, amount, payment_status, payment_method, transaction_id, card_number, card_name, card_expiry) VALUES (?, ?, 'Pending', ?, ?, ?, ?, ?)");
    $transaction_id = $payment_method === 'card' ? $transaction_id : $utr_no;
    $stmt->bind_param("idsssss", $booking_id, $total_price, $payment_method, $transaction_id, $card_number, $card_name, $card_expiry);
    $stmt->execute();

    // Commit transaction
    $conn->commit();

    // Clear booking data from session
    unset($_SESSION['booking_data']);
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    echo "<div class='container mt-5'><div class='alert alert-danger'>";
    echo "Error: " . htmlspecialchars($e->getMessage());
    echo "<br><a href='javascript:history.back()' class='btn btn-primary mt-3'>Go Back</a></div></div>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Payment Success</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <div class="alert alert-success">
        <h2>Booking Submitted!</h2>
        <p>Your booking is now <strong>pending</strong> admin approval.<br>
        Once your payment is verified, your booking will be confirmed.</p>
        <p><strong>Total Paid:</strong> ₹<?= htmlspecialchars($total_price) ?></p>
        <p><strong>Payment Method:</strong> <?= htmlspecialchars(strtoupper($payment_method)) ?></p>
        <?php if ($payment_method === 'card'): ?>
            <p><strong>Transaction ID:</strong> <?= htmlspecialchars($transaction_id) ?></p>
            <p><strong>Card Number:</strong> <?= htmlspecialchars($card_number) ?></p>
            <p><strong>Card Name:</strong> <?= htmlspecialchars($card_name) ?></p>
            <p><strong>Card Expiry:</strong> <?= htmlspecialchars($card_expiry) ?></p>
        <?php elseif ($payment_method === 'upi'): ?>
            <p><strong>UTR/Transaction No:</strong> <?= htmlspecialchars($utr_no) ?></p>
        <?php endif; ?>
        <a href="my_booking.php" class="btn btn-primary">View My Bookings</a>
    </div>
</div>
</body>
</html>