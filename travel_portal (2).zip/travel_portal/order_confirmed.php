<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Booking Confirmed</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <div class="alert alert-success">
        <h2>Booking Submitted!</h2>
        <p>Your booking is now <strong>pending</strong> admin approval.<br>
        Please pay at the property during check-in.</p>
        <a href="my_booking.php" class="btn btn-primary">View My Bookings</a>
    </div>
</div>
</body>
</html> 