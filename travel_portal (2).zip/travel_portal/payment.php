<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['booking_data'])) {
    header("Location: login.php");
    exit;
}
$booking = $_SESSION['booking_data'];
$total_price = $booking['total_price'];

if (!isset($_SESSION['booking_data'])) {
    echo "<div class='alert alert-danger'>Booking data missing. Please start your booking again.</div>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payment_method'])) {
    // ... collect all POST data ...
    $_SESSION['booking_data'] = [
        'room_id' => $room_id,
        'checkin' => $checkin,
        'checkout' => $checkout,
        'adults' => $adults,
        'children' => $children,
        'id_type' => $id_type,
        'id_number' => $id_number,
        'total_price' => $total_price
    ];
    header("Location: payment.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Payment Gateway</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8fafc; }
        .payment-card { max-width: 600px; margin: 40px auto; border-radius: 18px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
        .summary-card { background: linear-gradient(90deg, #4f8cff 0%, #38c6d9 100%); color: #fff; border-radius: 12px; padding: 18px; margin-bottom: 24px; }
        .nav-pills .nav-link.active { background: #4f8cff; color: #fff; }
        .nav-pills .nav-link { color: #4f8cff; font-weight: 500; }
        .fade-in { animation: fadeIn 0.7s; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        .form-icon { color: #38c6d9; margin-right: 8px; }
        .upi-qr { border-radius: 12px; border: 2px solid #e3e3e3; }
    </style>
    <script>
    function showPaymentForm(method) {
        document.getElementById('card-form').style.display = (method === 'card') ? 'block' : 'none';
        document.getElementById('upi-form').style.display = (method === 'upi') ? 'block' : 'none';
    }
    function validateCardForm() {
        var cardNum = document.getElementById('card-number').value;
        var name = document.getElementById('card-name').value;
        var expiry = document.getElementById('card-expiry').value;
        var cvv = document.getElementById('card-cvv').value;
        
        if (!/^\d{16}$/.test(cardNum.replace(/\s/g, ''))) {
            alert('Please enter a valid 16-digit card number.');
            return false;
        }
        if (name.trim() === '') {
            alert('Please enter the name on card.');
            return false;
        }
        if (!/^\d{2}\/\d{2}$/.test(expiry)) {
            alert('Please enter expiry in MM/YY format.');
            return false;
        }
        if (!/^\d{3}$/.test(cvv)) {
            alert('Please enter a valid 3-digit CVV.');
            return false;
        }
        
        // Generate transaction ID
        var transactionId = 'TXN' + Date.now() + Math.random().toString(36).substr(2, 5).toUpperCase();
        document.getElementById('transaction_id').value = transactionId;
        
        return true;
    }
    </script>
</head>
<body>
<div class="container">
    <div class="payment-card bg-white p-4 fade-in">
        <h3 class="mb-3 text-center" style="font-weight:600; color:#2d3a4b;"><i class="fa fa-credit-card form-icon"></i> Payment Gateway</h3>
        <div class="summary-card mb-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div style="font-size:1.1em;">Booking for <b><?= htmlspecialchars($booking['checkin']) ?></b> to <b><?= htmlspecialchars($booking['checkout']) ?></b></div>
                    <div style="font-size:0.95em;">Room ID: <?= htmlspecialchars($booking['room_id']) ?> | Adults: <?= htmlspecialchars($booking['adults']) ?> | Children: <?= htmlspecialchars($booking['children']) ?></div>
                </div>
                <div class="text-right">
                    <div style="font-size:1.5em; font-weight:700;">₹<?= number_format($total_price) ?></div>
                    <div style="font-size:0.9em;">Total incl. taxes</div>
                </div>
            </div>
        </div>
        <ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="pills-card-tab" data-toggle="pill" href="#pills-card" role="tab" aria-controls="pills-card" aria-selected="true" onclick="showPaymentForm('card')"><i class="fa fa-credit-card"></i> Card</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="pills-upi-tab" data-toggle="pill" href="#pills-upi" role="tab" aria-controls="pills-upi" aria-selected="false" onclick="showPaymentForm('upi')"><i class="fa fa-mobile-alt"></i> UPI</a>
            </li>
        </ul>
        <!-- Card Payment Form -->
        <form id="card-form" action="payment_success.php" method="POST" class="fade-in" onsubmit="return validateCardForm()">
            <?php foreach ($booking as $key => $value): ?>
                <input type="hidden" name="<?= htmlspecialchars($key) ?>" value="<?= htmlspecialchars($value) ?>">
            <?php endforeach; ?>
            <input type="hidden" name="payment_method" value="card">
            <input type="hidden" name="transaction_id" id="transaction_id">
            <div class="form-group">
                <label><i class="fa fa-credit-card form-icon"></i>Card Number</label>
                <input type="text" class="form-control" id="card-number" name="card_number" placeholder="1234 5678 9012 3456" maxlength="19" required>
            </div>
            <div class="form-group">
                <label><i class="fa fa-user form-icon"></i>Name on Card</label>
                <input type="text" class="form-control" id="card-name" name="card_name" placeholder="Your Name" required>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label><i class="fa fa-calendar-alt form-icon"></i>Expiry</label>
                    <input type="text" class="form-control" id="card-expiry" name="card_expiry" placeholder="MM/YY" maxlength="5" required>
                </div>
                <div class="form-group col-md-6">
                    <label><i class="fa fa-lock form-icon"></i>CVV</label>
                    <input type="password" class="form-control" id="card-cvv" placeholder="123" maxlength="3" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block mt-2">Pay Now</button>
        </form>
        <!-- UPI Payment Form -->
        <form id="upi-form" action="payment_success.php" method="POST" class="fade-in" style="display:none;">
            <?php foreach ($booking as $key => $value): ?>
                <input type="hidden" name="<?= htmlspecialchars($key) ?>" value="<?= htmlspecialchars($value) ?>">
            <?php endforeach; ?>
            <input type="hidden" name="payment_method" value="upi">
            <div class="form-group text-center">
                <label><i class="fa fa-qrcode form-icon"></i>Scan this QR code to pay:</label><br>
                <img src="assets/images/qr.jpg" alt="UPI QR Code" class="upi-qr mb-2" style="width:180px;height:180px;">
            </div>
            <div class="form-group">
                <label><i class="fa fa-receipt form-icon"></i>Enter UTR/Transaction Number</label>
                <input type="text" name="utr_no" class="form-control" placeholder="Enter UTR/Transaction Number" required>
            </div>
            <button type="submit" class="btn btn-success btn-block mt-2">Confirm Payment</button>
        </form>
        <form method="post" style="margin:0;" id="payAtPropertyForm">
            <input type="hidden" name="room_id" value="<?= $room['id'] ?>">
            <input type="hidden" name="checkin" value="">
            <input type="hidden" name="checkout" value="">
            <input type="hidden" name="adults" value="">
            <input type="hidden" name="children" value="">
            <input type="hidden" name="id_type" value="">
            <input type="hidden" name="id_number" value="">
            <input type="hidden" name="payment_method" value="pay_at_property">
            <input type="hidden" name="total_price" value="<?= $total_price ?>">
        </form>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Default to card form
    showPaymentForm('card');

    $('#paymentOptionsModal').on('show.bs.modal', function () {
        // Get values from the main form
        var checkin = $('input[name="checkin"]').val();
        var checkout = $('input[name="checkout"]').val();
        var adults = $('input[name="adults"]').val();
        var children = $('input[name="children"]').val();
        var id_type = $('select[name="id_type"]').val();
        var id_number = $('input[name="id_number"]').val();

        // Set them in the hidden fields of the modal forms
        $('#payNowForm input[name="checkin"]').val(checkin);
        $('#payNowForm input[name="checkout"]').val(checkout);
        $('#payNowForm input[name="adults"]').val(adults);
        $('#payNowForm input[name="children"]').val(children);
        $('#payNowForm input[name="id_type"]').val(id_type);
        $('#payNowForm input[name="id_number"]').val(id_number);

        // Do the same for the pay-at-property form
        $('#payAtPropertyForm input[name="checkin"]').val(checkin);
        $('#payAtPropertyForm input[name="checkout"]').val(checkout);
        $('#payAtPropertyForm input[name="adults"]').val(adults);
        $('#payAtPropertyForm input[name="children"]').val(children);
        $('#payAtPropertyForm input[name="id_type"]').val(id_type);
        $('#payAtPropertyForm input[name="id_number"]').val(id_number);
    });
</script>
</body>
</html>