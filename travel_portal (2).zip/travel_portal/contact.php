<?php
session_start();
$success = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $success = "Thank you for contacting us! We'll get back to you soon.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact Us - Travel Portal</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:700,400&display=swap" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(120deg, #43cea2 0%, #185a9d 100%);
            min-height: 100vh;
            font-family: 'Montserrat', sans-serif;
        }
        .contact-glass {
            background: rgba(255,255,255,0.85);
            border-radius: 24px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.12);
            padding: 2.5rem 2rem;
            margin-top: 40px;
            margin-bottom: 40px;
            backdrop-filter: blur(6px);
        }
        .contact-info i {
            color: #43cea2;
            font-size: 1.5rem;
            margin-right: 12px;
        }
        .form-control, .btn {
            border-radius: 12px;
        }
        .btn-contact {
            background: linear-gradient(90deg, #43cea2 0%, #185a9d 100%);
            color: #fff;
            font-weight: bold;
            border: none;
            box-shadow: 0 2px 8px rgba(67,206,162,0.15);
            transition: background 0.3s, transform 0.2s;
        }
        .btn-contact:hover {
            background: linear-gradient(90deg, #185a9d 0%, #43cea2 100%);
            color: #fff;
            transform: translateY(-2px) scale(1.04);
        }
        .contact-title {
            font-weight: bold;
            color: #185a9d;
            letter-spacing: 1px;
        }
        .contact-subtitle {
            color: #333;
            font-size: 1.1rem;
        }
        .social-icons a {
            margin-right: 18px;
            font-size: 1.5rem;
            transition: color 0.2s;
        }
        .social-icons a:hover { color: #43cea2; }
        .map-embed {
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
            margin-top: 30px;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container py-5">
    <?php if ($success): ?>
      <div class="alert alert-success text-center"><?= $success ?></div>
    <?php endif; ?>

    <div class="text-center mb-4">
      <h1 class="contact-title">Contact Us</h1>
      <p class="contact-subtitle">We'd love to hear from you! Reach out with any questions or feedback.</p>
    </div>
    <div class="contact-glass">
      <div class="row">
        <div class="col-md-6 mb-4 mb-md-0">
          <h2 class="mb-3" style="font-weight:bold; color:#185a9d;">Get in Touch</h2>
          <p style="font-size:1.1rem; color:#333;">
            Our team is here for you 24/7!
          </p>
          <div class="contact-info mb-3">
            <p><i class="fa fa-envelope"></i> support@travelportal.com</p>
            <p><i class="fa fa-phone"></i> +91 98765 43210</p>
            <p><i class="fa fa-map-marker-alt"></i> Mumbai, India</p>
          </div>
          <div class="social-icons mt-3">
            <a href="https://facebook.com" class="text-primary"><i class="fab fa-facebook"></i></a>
            <a href="https://twitter.com" class="text-info"><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com" class="text-danger"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
        <div class="col-md-6">
          <form method="post" action="">
            <div class="form-group mb-3">
              <label for="name">Your Name</label>
              <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="form-group mb-3">
              <label for="email">Your Email</label>
              <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group mb-3">
              <label for="message">Message</label>
              <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-contact px-4 py-2">Send Message</button>
          </form>
        </div>
      </div>
    </div>
    <!-- Google Map -->
    <div class="row justify-content-center">
      <div class="col-md-10 map-embed">
        <iframe src="https://www.google.com/maps?q=shrirampur,India&output=embed" width="100%" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </div>
    </div>
</div>
</body>
</html>