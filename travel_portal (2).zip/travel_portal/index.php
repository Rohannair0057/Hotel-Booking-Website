<?php 
session_start(); 
require_once 'includes/db.php';  // Add database connection
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Travel Portal - Book Your Stay</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- In your <head> -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; }
        .hero {
            background: url('assets/images/hero-bg.jpg') center center/cover no-repeat;
            color: #fff;
            padding: 120px 0 80px 0;
            text-shadow: 2px 2px 8px #000;
            position: relative;
        }
        .hero-overlay {
            position: absolute;
            top:0; left:0; right:0; bottom:0;
            background: rgba(0,0,0,0.4);
        }
        .hero-content {
            position: relative;
            z-index: 2;
        }
        .property-card .card {
            transition: transform 0.2s, box-shadow 0.2s;
            border-radius: 18px;
        }
        .property-card .card:hover {
            transform: translateY(-8px) scale(1.03);
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            border: 1.5px solid #007bff;
        }
        .property-img {
            height: 170px;
            object-fit: cover;
            border-radius: 18px 18px 0 0;
        }
        .destination-card .card {
            border-radius: 18px;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .destination-card .card:hover {
            transform: translateY(-8px) scale(1.03);
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            border: 1.5px solid #28a745;
        }
        .destination-img {
            height: 140px;
            object-fit: cover;
            border-radius: 18px 18px 0 0;
        }
        .feature-icon {
            height: 100px;
            margin-bottom: 20px;
        }
        .feature-box {
            transition: transform 0.2s, box-shadow 0.2s;
            border-radius: 18px;
            background: #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            padding: 30px 10px 20px 10px;
        }
        .feature-box:hover {
            transform: translateY(-8px) scale(1.03);
            box-shadow: 0 8px 32px rgba(255,65,108,0.10);
            background: #fff7f7;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<!-- Carousel Background -->
<div style="position:relative; height:500px; overflow:hidden;">
  <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="3500" style="height:500px;">
    <div class="carousel-inner" style="height:500px;">
      <div class="carousel-item active">
        <img src="assets/images/banner1.png" class="d-block w-100" style="height:500px; object-fit:cover; filter:brightness(0.6);" alt="...">
      </div>
      <div class="carousel-item">
        <img src="assets/images/banner2.png" class="d-block w-100" style="height:500px; object-fit:cover; filter:brightness(0.6);" alt="...">
      </div>
      <div class="carousel-item">
        <img src="assets/images/banner3.png" class="d-block w-100" style="height:500px; object-fit:cover; filter:brightness(0.6);" alt="...">
      </div>
    </div>
  </div>
  <!-- Gradient Overlayed Hero/Search Section -->
  <div style="
    position:absolute;
    top:0; left:0; width:100%; height:100%;
    display:flex; flex-direction:column; align-items:center; justify-content:center;
    z-index:2;
  ">
    <h1 class="display-3 font-weight-bold text-white mb-3" style="text-shadow:2px 2px 12px #000;">Find Your Perfect Stay</h1>
    <p class="lead text-white mb-4" style="text-shadow:1px 1px 6px #000;">Hotels, Villas, Apartments, Resorts – Book as you wish!</p>
    <form action="search.php" method="GET" class="d-flex justify-content-center mb-3">
      <input type="text" name="location" class="form-control mx-2" placeholder="Location" style="max-width:200px;">
      <input type="date" name="checkin" class="form-control mx-2" placeholder="Check-in" style="max-width:180px;" min="<?= date('Y-m-d') ?>" required>
      <input type="date" name="checkout" class="form-control mx-2" placeholder="Check-out" style="max-width:180px;" min="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
      <button class="btn btn-warning mx-2 px-4 py-2" type="submit" style="font-size:1.2rem;"><i class="fa fa-search"></i> Search</button>
    </form>
    <a href="#offers" class="btn btn-light btn-lg mt-2" style="font-weight:bold; border-radius:30px; box-shadow:0 2px 8px rgba(0,0,0,0.12);">See Today's Deals</a>
  </div>
</div>
<!-- Browse by property type -->
<div class="container mb-5">
    <h2 class="mb-4" style="font-weight: bold;">Browse by property type</h2>
    <div class="row justify-content-center">
        <div class="col-6 col-sm-4 col-md-3 mb-4 property-card">
            <a href="search.php?property_type=Hotel" class="text-decoration-none text-dark">
                <div class="card shadow-sm border-0 h-100">
                    <img src="assets/images/hotel.webp" class="card-img-top property-img" alt="Hotels">
                    <div class="card-body text-center">
                        <h5 class="card-title mb-0" style="font-weight: bold;">Hotels</h5>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-6 col-sm-4 col-md-3 mb-4 property-card">
            <a href="search.php?property_type=Apartment" class="text-decoration-none text-dark">
                <div class="card shadow-sm border-0 h-100">
                    <img src="assets/images/apartment.jpg" class="card-img-top property-img" alt="Apartments">
                    <div class="card-body text-center">
                        <h5 class="card-title mb-0" style="font-weight: bold;">Apartments</h5>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-6 col-sm-4 col-md-3 mb-4 property-card">
            <a href="search.php?property_type=Resort" class="text-decoration-none text-dark">
                <div class="card shadow-sm border-0 h-100">
                    <img src="assets/images/Resort.webp" class="card-img-top property-img" alt="Resorts">
                    <div class="card-body text-center">
                        <h5 class="card-title mb-0" style="font-weight: bold;">Resorts</h5>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-6 col-sm-4 col-md-3 mb-4 property-card">
            <a href="search.php?property_type=Villa" class="text-decoration-none text-dark">
                <div class="card shadow-sm border-0 h-100">
                    <img src="assets/images/villa.jpg" class="card-img-top property-img" alt="Villas">
                    <div class="card-body text-center">
                        <h5 class="card-title mb-0" style="font-weight: bold;">Villas</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>


<div class="container my-5">
  <div class="row text-center">
    <div class="col-md-4 mb-4 feature-box">
      <img src="assets/images/search-simply.jpg" alt="Search simply" class="feature-icon">
      <h4 class="mt-3 font-weight-bold">Search simply</h4>
      <p>Easily search through millions of hotels in seconds.</p>
    </div>
    <div class="col-md-4 mb-4 feature-box">
      <img src="assets/images/compare-confidently.png" alt="Compare confidently" class="feature-icon">
      <h4 class="mt-3 font-weight-bold">Compare confidently</h4>
      <p>Compare hotel prices from over 100 sites at once.</p>
    </div>
    <div class="col-md-4 mb-4 feature-box">
      <img src="assets/images/save-big.png" alt="Save big" class="feature-icon">
      <h4 class="mt-3 font-weight-bold">Save big</h4>
      <p>Discover a great deal to book on our partner sites.</p>
    </div>
  </div>
</div>

<!-- Offer Banner -->
<div class="container my-4">
  <div class="offer-banner d-flex flex-column flex-md-row align-items-center justify-content-between p-4 rounded shadow" style="background: linear-gradient(90deg, #ff416c 0%, #ff4b2b 100%); color: #fff;">
    <div class="d-flex align-items-center mb-3 mb-md-0">
      <img src="assets/images/special-offer.jpg" alt="Special Offer" style="height:60px; margin-right: 20px;">
      <div>
        <span class="badge bg-warning text-dark mb-2" style="font-size:1rem; font-weight:bold;">HOT DEAL</span>
        <h3 class="mb-1" style="font-weight: bold;">Limited Time Offer!</h3>
        <p class="mb-0">Get <span style="font-weight:bold; color:#ffe066;">20% OFF</span> on your first booking. Use code <span style="font-weight:bold; color:#ffe066;">WELCOME20</span></p>
      </div>
    </div>
    <a href="search.php" class="btn btn-warning btn-lg" style="font-weight: bold; box-shadow: 0 2px 8px rgba(0,0,0,0.12);">Book Now</a>
  </div>
</div>

<br>
<br>



<!-- Top Destinations -->
<?php
$top_destinations = [
    [
        'city' => 'Mumbai',
        'image' => 'mumbai.jpg'
    ],
    [
        'city' => 'Goa',
        'image' => 'goa.jpg'
    ],
    [
        'city' => 'Kerala',
        'image' => 'kerala.jpg'
    ],
    [
        'city' => 'Bangalore',
        'image' => 'bangalore.jpg'
    ]
];
?>

<div class="container mb-5">
    <h2 class="mb-4" style="font-weight: bold;">Top Destinations</h2>
    <div class="row">
        <?php foreach($top_destinations as $destination): ?>
            <div class="col-md-3 mb-4 destination-card">
                <a href="search.php?location=<?= urlencode($destination['city']) ?>" class="text-decoration-none text-dark">
                    <div class="card h-100 shadow">
                        <img src="assets/images/<?= htmlspecialchars($destination['image']) ?>" class="card-img-top destination-img" alt="<?= htmlspecialchars($destination['city']) ?>">
                        <div class="card-body text-center">
                            <h5 class="card-title mb-2" style="font-weight: bold;"><?= htmlspecialchars($destination['city']) ?></h5>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Footer -->
<footer class="bg-primary text-white text-center py-3">
    &copy; <?php echo date('Y'); ?> Travel Portal. All rights reserved.
</footer>
<!-- Before </body> -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>