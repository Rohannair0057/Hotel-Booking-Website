-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2025 at 12:00 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travel_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'rohan@gmail.com', 'rohan@57');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `check_in` date DEFAULT NULL,
  `check_out` date DEFAULT NULL,
  `adults` int(11) DEFAULT NULL,
  `children` int(11) DEFAULT NULL,
  `id_type` varchar(50) DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

-- Delete all bookings
DELETE FROM `bookings`;

--
-- Dumping data for table `destinations`
--

CREATE TABLE `destinations` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `type` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destinations`
--

-- Delete old destinations
DELETE FROM `destinations` WHERE `id` BETWEEN 1 AND 248;

INSERT INTO `destinations` (`id`, `name`, `image`, `city`, `type`) VALUES
-- Mumbai Hotels
(100, 'The Oberoi Mumbai', 'oberoi_mumbai.jpg', 'Mumbai', 34),
(101, 'Trident Nariman Point', 'trident_mumbai.jpg', 'Mumbai', 34),

-- Mumbai Apartments
(102, 'Marine Drive Luxury Apartment', 'marine_drive.jpg', 'Mumbai', 33),
(103, 'Powai Lake Executive Apartment', 'powai_apartment.jpg', 'Mumbai', 33),

-- Mumbai Villas
(104, 'Palm Grove Villa', 'palm_grove.jpg', 'Mumbai', 35),
(105, 'Juhu Beach Villa', 'juhu_villa.jpg', 'Mumbai', 35),

-- Mumbai Resorts
(106, 'Sunset Bay Resort', 'sunset_bay.jpg', 'Mumbai', 36),
(107, 'The Retreat Mumbai', 'retreat_mumbai.jpg', 'Mumbai', 36),

-- Bangalore Hotels
(108, 'Taj West End', 'taj_westend.jpg', 'Bangalore', 34),
(109, 'ITC Gardenia', 'itc_gardenia.jpg', 'Bangalore', 34),

-- Bangalore Apartments
(110, 'Indiranagar Executive Suites', 'indiranagar.jpg', 'Bangalore', 33),
(111, 'Koramangala Urban Suites', 'koramangala.jpg', 'Bangalore', 33),

-- Bangalore Villas
(112, 'Whitefield Garden Villa', 'whitefield.jpg', 'Bangalore', 35),
(113, 'Hebbal Lake Villa', 'hebbal_villa.jpg', 'Bangalore', 35),

-- Bangalore Resorts
(114, 'Nandi Hills Retreat', 'nandi_hills.jpg', 'Bangalore', 36),
(115, 'Golden Palms Resort', 'golden_palms.jpg', 'Bangalore', 36),

-- Kerala Hotels
(116, 'Leela Kovalam Beach', 'leela_kovalam.jpg', 'Kerala', 34),
(117, 'Vivanta by Taj Malabar', 'vivanta_taj.jpg', 'Kerala', 34),

-- Kerala Apartments
(118, 'Backwater View Apartments', 'backwater.jpg', 'Kerala', 33),
(119, 'Cochin Riverside Apartments', 'cochin_apartment.jpg', 'Kerala', 33),

-- Kerala Villas
(120, 'Alleppey Lake Villa', 'alleppey.jpg', 'Kerala', 35),
(121, 'Munnar Hilltop Villa', 'munnar_villa.jpg', 'Kerala', 35),

-- Kerala Resorts
(122, 'Kumarakom Lake Resort', 'kumarakom.jpg', 'Kerala', 36),
(123, 'Vythiri Village Resort', 'vythiri_village.jpg', 'Kerala', 36),

-- Goa Hotels
(124, 'Taj Exotica Resort & Spa', 'taj_exotica.jpg', 'Goa', 34),
(125, 'Park Hyatt Goa Resort', 'park_hyatt.jpg', 'Goa', 34),

-- Goa Apartments
(126, 'Calangute Beachfront Apartment', 'calangute.jpg', 'Goa', 33),
(127, 'Candolim Beach Apartments', 'candolim.jpg', 'Goa', 33),

-- Goa Villas
(128, 'Anjuna Private Villa', 'anjuna.jpg', 'Goa', 35),
(129, 'Morjim Luxury Villa', 'morjim_villa.jpg', 'Goa', 35),

-- Goa Resorts
(130, 'Baga Beach Resort', 'baga_beach.jpg', 'Goa', 36),
(131, 'Caravela Beach Resort', 'caravela.jpg', 'Goa', 36),

-- Nagar Hotels
(132, 'Hotel Nagar Palace', 'nagar_palace.jpg', 'Nagar', 34),
(133, 'Royal Nagar Hotel', 'royal_nagar.jpg', 'Nagar', 34),

-- Nagar Apartments
(134, 'Nagar City Apartments', 'nagar_city.jpg', 'Nagar', 33),
(135, 'Nagar Executive Suites', 'nagar_executive.jpg', 'Nagar', 33),

-- Nagar Villas
(136, 'Nagar Garden Villa', 'nagar_garden.jpg', 'Nagar', 35),
(137, 'Nagar Lake Villa', 'nagar_lake.jpg', 'Nagar', 35),

-- Nagar Resorts
(138, 'Nagar Valley Resort', 'nagar_valley.jpg', 'Nagar', 36),
(139, 'Nagar Hills Resort', 'nagar_hills.jpg', 'Nagar', 36),

-- Nashik Hotels
(140, 'The Gateway Hotel Nashik', 'gateway_nashik.jpg', 'Nashik', 34),
(141, 'Express Inn Nashik', 'express_nashik.jpg', 'Nashik', 34),

-- Nashik Apartments
(142, 'Nashik City Apartments', 'nashik_city.jpg', 'Nashik', 33),
(143, 'Nashik Executive Suites', 'nashik_executive.jpg', 'Nashik', 33),

-- Nashik Villas
(144, 'Nashik Garden Villa', 'nashik_garden.jpg', 'Nashik', 35),
(145, 'Nashik Lake Villa', 'nashik_lake.jpg', 'Nashik', 35),

-- Nashik Resorts
(146, 'Nashik Valley Resort', 'nashik_valley.jpg', 'Nashik', 36),
(147, 'Nashik Hills Resort', 'nashik_hills.jpg', 'Nashik', 36),

-- Pune Hotels
(148, 'JW Marriott Pune', 'jw_pune.jpg', 'Pune', 34),
(149, 'Hyatt Pune', 'hyatt_pune.jpg', 'Pune', 34),

-- Pune Apartments
(150, 'Pune City Apartments', 'pune_city.jpg', 'Pune', 33),
(151, 'Pune Executive Suites', 'pune_executive.jpg', 'Pune', 33),

-- Pune Villas
(152, 'Pune Garden Villa', 'pune_garden.jpg', 'Pune', 35),
(153, 'Pune Lake Villa', 'pune_lake.jpg', 'Pune', 35),

-- Pune Resorts
(154, 'Pune Valley Resort', 'pune_valley.jpg', 'Pune', 36),
(155, 'Pune Hills Resort', 'pune_hills.jpg', 'Pune', 36),

-- Shirdi Hotels
(156, 'Hotel Sai Leela', 'sai_leela.jpg', 'Shirdi', 34),
(157, 'Shirdi Grand Hotel', 'shirdi_grand.jpg', 'Shirdi', 34),

-- Shirdi Apartments
(158, 'Shirdi City Apartments', 'shirdi_city.jpg', 'Shirdi', 33),
(159, 'Shirdi Executive Suites', 'shirdi_executive.jpg', 'Shirdi', 33),

-- Shirdi Villas
(160, 'Shirdi Garden Villa', 'shirdi_garden.jpg', 'Shirdi', 35),
(161, 'Shirdi Lake Villa', 'shirdi_lake.jpg', 'Shirdi', 35),

-- Shirdi Resorts
(162, 'Shirdi Valley Resort', 'shirdi_valley.jpg', 'Shirdi', 36),
(163, 'Shirdi Hills Resort', 'shirdi_hills.jpg', 'Shirdi', 36);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_status` varchar(20) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

-- Delete all payments
DELETE FROM `payments`;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `room_type_id` int(11) DEFAULT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `facilities` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `total_rooms` int(11) DEFAULT NULL,
  `available_rooms` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

-- Delete all rooms
DELETE FROM `rooms`;

-- Insert rooms for all destinations
INSERT INTO `rooms` (`id`, `room_type_id`, `destination_id`, `name`, `description`, `facilities`, `price`, `image`, `total_rooms`, `available_rooms`) VALUES
-- Mumbai Hotels
(200, 34, 100, 'Deluxe Room', 'Spacious deluxe room with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 15000.00, 'oberoi_deluxe.jpg', 5, 5),
(201, 34, 100, 'Executive Suite', 'Luxurious suite with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 25000.00, 'oberoi_suite.jpg', 3, 3),
(202, 34, 101, 'Deluxe Room', 'Elegant room with sea view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 12000.00, 'trident_deluxe.jpg', 5, 5),
(203, 34, 101, 'Executive Suite', 'Premium suite with sea view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 20000.00, 'trident_suite.jpg', 3, 3),

-- Mumbai Apartments
(204, 33, 102, '1 BHK Apartment', 'Cozy 1 bedroom apartment with sea view', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 8000.00, 'marine_1bhk.jpg', 3, 3),
(205, 33, 102, '2 BHK Apartment', 'Spacious 2 bedroom apartment with sea view', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 15000.00, 'marine_2bhk.jpg', 2, 2),
(206, 33, 103, '1 BHK Executive Suite', 'Modern 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine, Work desk', 9000.00, 'powai_1bhk.jpg', 3, 3),
(207, 33, 103, '2 BHK Executive Suite', 'Contemporary 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room, Work desk', 16000.00, 'powai_2bhk.jpg', 2, 2),

-- Mumbai Villas (Direct Booking)
(208, 35, 104, 'Luxury Villa', 'Exclusive private villa with pool', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Private pool, Garden, Butler service', 35000.00, 'palm_villa.jpg', 1, 1),
(209, 35, 105, 'Beachfront Villa', 'Luxury villa with beach access', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Private pool, Garden, Beach access, Butler service', 45000.00, 'juhu_villa.jpg', 1, 1),

-- Mumbai Resorts
(210, 36, 106, 'Standard Room', 'Comfortable resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 12000.00, 'sunset_standard.jpg', 5, 5),
(211, 36, 106, 'Deluxe Room', 'Spacious deluxe room with sea view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 18000.00, 'sunset_deluxe.jpg', 3, 3),
(212, 36, 107, 'Standard Room', 'Cozy resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'retreat_standard.jpg', 5, 5),
(213, 36, 107, 'Deluxe Room', 'Spacious deluxe room', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 15000.00, 'retreat_deluxe.jpg', 3, 3),

-- Bangalore Hotels
(214, 34, 108, 'Deluxe Room', 'Luxury room with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 12000.00, 'taj_deluxe.jpg', 5, 5),
(215, 34, 108, 'Executive Suite', 'Premium suite with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 20000.00, 'taj_suite.jpg', 3, 3),
(216, 34, 109, 'Deluxe Room', 'Modern room with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'itc_deluxe.jpg', 5, 5),
(217, 34, 109, 'Executive Suite', 'Spacious suite with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 18000.00, 'itc_suite.jpg', 3, 3),

-- Bangalore Apartments
(218, 33, 110, '1 BHK Executive Suite', 'Modern 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine, Work desk', 8000.00, 'indiranagar_1bhk.jpg', 3, 3),
(219, 33, 110, '2 BHK Executive Suite', 'Contemporary 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room, Work desk', 15000.00, 'indiranagar_2bhk.jpg', 2, 2),
(220, 33, 111, '1 BHK Urban Suite', 'Stylish 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 7000.00, 'koramangala_1bhk.jpg', 3, 3),
(221, 33, 111, '2 BHK Urban Suite', 'Modern 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 13000.00, 'koramangala_2bhk.jpg', 2, 2),

-- Bangalore Villas (Direct Booking)
(222, 35, 112, 'Garden Villa', 'Luxury villa with garden', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Private garden, Butler service', 30000.00, 'whitefield_villa.jpg', 1, 1),
(223, 35, 113, 'Lake View Villa', 'Exclusive villa with lake view', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Lake view, Private pool, Butler service', 40000.00, 'hebbal_villa.jpg', 1, 1),

-- Bangalore Resorts
(224, 36, 114, 'Standard Room', 'Comfortable resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'nandi_standard.jpg', 5, 5),
(225, 36, 114, 'Deluxe Room', 'Spacious deluxe room with hill view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 15000.00, 'nandi_deluxe.jpg', 3, 3),
(226, 36, 115, 'Standard Room', 'Cozy resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 8000.00, 'golden_standard.jpg', 5, 5),
(227, 36, 115, 'Deluxe Room', 'Spacious deluxe room', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 12000.00, 'golden_deluxe.jpg', 3, 3),

-- Kerala Hotels
(228, 34, 116, 'Deluxe Room', 'Luxury room with beach view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 12000.00, 'leela_deluxe.jpg', 5, 5),
(229, 34, 116, 'Executive Suite', 'Premium suite with beach view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 20000.00, 'leela_suite.jpg', 3, 3),
(230, 34, 117, 'Deluxe Room', 'Modern room with sea view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'vivanta_deluxe.jpg', 5, 5),
(231, 34, 117, 'Executive Suite', 'Spacious suite with sea view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 18000.00, 'vivanta_suite.jpg', 3, 3),

-- Kerala Apartments
(232, 33, 118, '1 BHK Backwater Suite', 'Cozy 1 bedroom suite with backwater view', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 7000.00, 'backwater_1bhk.jpg', 3, 3),
(233, 33, 118, '2 BHK Backwater Suite', 'Spacious 2 bedroom suite with backwater view', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 13000.00, 'backwater_2bhk.jpg', 2, 2),
(234, 33, 119, '1 BHK Riverside Suite', 'Modern 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 8000.00, 'cochin_1bhk.jpg', 3, 3),
(235, 33, 119, '2 BHK Riverside Suite', 'Contemporary 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 15000.00, 'cochin_2bhk.jpg', 2, 2),

-- Kerala Villas (Direct Booking)
(236, 35, 120, 'Lake Villa', 'Luxury villa with lake view', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Lake view, Private pool, Butler service', 35000.00, 'alleppey_villa.jpg', 1, 1),
(237, 35, 121, 'Hilltop Villa', 'Exclusive villa with hill view', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Hill view, Private pool, Butler service', 40000.00, 'munnar_villa.jpg', 1, 1),

-- Kerala Resorts
(238, 36, 122, 'Standard Room', 'Comfortable resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'kumarakom_standard.jpg', 5, 5),
(239, 36, 122, 'Deluxe Room', 'Spacious deluxe room with lake view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 15000.00, 'kumarakom_deluxe.jpg', 3, 3),
(240, 36, 123, 'Standard Room', 'Cozy resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 8000.00, 'vythiri_standard.jpg', 5, 5),
(241, 36, 123, 'Deluxe Room', 'Spacious deluxe room', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 12000.00, 'vythiri_deluxe.jpg', 3, 3),

-- Goa Hotels
(242, 34, 124, 'Deluxe Room', 'Luxury room with beach view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 12000.00, 'taj_goa_deluxe.jpg', 5, 5),
(243, 34, 124, 'Executive Suite', 'Premium suite with beach view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 20000.00, 'taj_goa_suite.jpg', 3, 3),
(244, 34, 125, 'Deluxe Room', 'Modern room with sea view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'hyatt_deluxe.jpg', 5, 5),
(245, 34, 125, 'Executive Suite', 'Spacious suite with sea view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 18000.00, 'hyatt_suite.jpg', 3, 3),

-- Goa Apartments
(246, 33, 126, '1 BHK Beachfront Suite', 'Cozy 1 bedroom suite with beach view', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 7000.00, 'calangute_1bhk.jpg', 3, 3),
(247, 33, 126, '2 BHK Beachfront Suite', 'Spacious 2 bedroom suite with beach view', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 13000.00, 'calangute_2bhk.jpg', 2, 2),
(248, 33, 127, '1 BHK Beach Suite', 'Modern 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 8000.00, 'candolim_1bhk.jpg', 3, 3),
(249, 33, 127, '2 BHK Beach Suite', 'Contemporary 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 15000.00, 'candolim_2bhk.jpg', 2, 2),

-- Goa Villas (Direct Booking)
(250, 35, 128, 'Beach Villa', 'Luxury villa with beach access', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Beach access, Private pool, Butler service', 40000.00, 'anjuna_villa.jpg', 1, 1),
(251, 35, 129, 'Luxury Villa', 'Exclusive villa with sea view', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Sea view, Private pool, Butler service', 45000.00, 'morjim_villa.jpg', 1, 1),

-- Goa Resorts
(252, 36, 130, 'Standard Room', 'Comfortable resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'baga_standard.jpg', 5, 5),
(253, 36, 130, 'Deluxe Room', 'Spacious deluxe room with beach view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 15000.00, 'baga_deluxe.jpg', 3, 3),
(254, 36, 131, 'Standard Room', 'Cozy resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 8000.00, 'caravela_standard.jpg', 5, 5),
(255, 36, 131, 'Deluxe Room', 'Spacious deluxe room', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 12000.00, 'caravela_deluxe.jpg', 3, 3),

-- Nagar Hotels
(256, 34, 132, 'Deluxe Room', 'Luxury room with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'nagar_palace_deluxe.jpg', 5, 5),
(257, 34, 132, 'Executive Suite', 'Premium suite with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 18000.00, 'nagar_palace_suite.jpg', 3, 3),
(258, 34, 133, 'Deluxe Room', 'Modern room with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 9000.00, 'royal_nagar_deluxe.jpg', 5, 5),
(259, 34, 133, 'Executive Suite', 'Spacious suite with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 16000.00, 'royal_nagar_suite.jpg', 3, 3),

-- Nagar Apartments
(260, 33, 134, '1 BHK City Suite', 'Cozy 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 6000.00, 'nagar_city_1bhk.jpg', 3, 3),
(261, 33, 134, '2 BHK City Suite', 'Spacious 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 12000.00, 'nagar_city_2bhk.jpg', 2, 2),
(262, 33, 135, '1 BHK Executive Suite', 'Modern 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine, Work desk', 7000.00, 'nagar_executive_1bhk.jpg', 3, 3),
(263, 33, 135, '2 BHK Executive Suite', 'Contemporary 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room, Work desk', 13000.00, 'nagar_executive_2bhk.jpg', 2, 2),

-- Nagar Villas (Direct Booking)
(264, 35, 136, 'Garden Villa', 'Luxury villa with garden', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Private garden, Butler service', 30000.00, 'nagar_garden_villa.jpg', 1, 1),
(265, 35, 137, 'Lake Villa', 'Exclusive villa with lake view', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Lake view, Private pool, Butler service', 35000.00, 'nagar_lake_villa.jpg', 1, 1),

-- Nagar Resorts
(266, 36, 138, 'Standard Room', 'Comfortable resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 8000.00, 'nagar_valley_standard.jpg', 5, 5),
(267, 36, 138, 'Deluxe Room', 'Spacious deluxe room with valley view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 12000.00, 'nagar_valley_deluxe.jpg', 3, 3),
(268, 36, 139, 'Standard Room', 'Cozy resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 7000.00, 'nagar_hills_standard.jpg', 5, 5),
(269, 36, 139, 'Deluxe Room', 'Spacious deluxe room', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 11000.00, 'nagar_hills_deluxe.jpg', 3, 3),

-- Nashik Hotels
(270, 34, 140, 'Deluxe Room', 'Luxury room with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'gateway_deluxe.jpg', 5, 5),
(271, 34, 140, 'Executive Suite', 'Premium suite with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 18000.00, 'gateway_suite.jpg', 3, 3),
(272, 34, 141, 'Deluxe Room', 'Modern room with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 9000.00, 'express_deluxe.jpg', 5, 5),
(273, 34, 141, 'Executive Suite', 'Spacious suite with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 16000.00, 'express_suite.jpg', 3, 3),

-- Nashik Apartments
(274, 33, 142, '1 BHK City Suite', 'Cozy 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 6000.00, 'nashik_city_1bhk.jpg', 3, 3),
(275, 33, 142, '2 BHK City Suite', 'Spacious 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 12000.00, 'nashik_city_2bhk.jpg', 2, 2),
(276, 33, 143, '1 BHK Executive Suite', 'Modern 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine, Work desk', 7000.00, 'nashik_executive_1bhk.jpg', 3, 3),
(277, 33, 143, '2 BHK Executive Suite', 'Contemporary 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room, Work desk', 13000.00, 'nashik_executive_2bhk.jpg', 2, 2),

-- Nashik Villas (Direct Booking)
(278, 35, 144, 'Garden Villa', 'Luxury villa with garden', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Private garden, Butler service', 30000.00, 'nashik_garden_villa.jpg', 1, 1),
(279, 35, 145, 'Lake Villa', 'Exclusive villa with lake view', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Lake view, Private pool, Butler service', 35000.00, 'nashik_lake_villa.jpg', 1, 1),

-- Nashik Resorts
(280, 36, 146, 'Standard Room', 'Comfortable resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 8000.00, 'nashik_valley_standard.jpg', 5, 5),
(281, 36, 146, 'Deluxe Room', 'Spacious deluxe room with valley view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 12000.00, 'nashik_valley_deluxe.jpg', 3, 3),
(282, 36, 147, 'Standard Room', 'Cozy resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 7000.00, 'nashik_hills_standard.jpg', 5, 5),
(283, 36, 147, 'Deluxe Room', 'Spacious deluxe room', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 11000.00, 'nashik_hills_deluxe.jpg', 3, 3),

-- Pune Hotels
(284, 34, 148, 'Deluxe Room', 'Luxury room with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 12000.00, 'jw_deluxe.jpg', 5, 5),
(285, 34, 148, 'Executive Suite', 'Premium suite with city view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 20000.00, 'jw_suite.jpg', 3, 3),
(286, 34, 149, 'Deluxe Room', 'Modern room with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'hyatt_deluxe.jpg', 5, 5),
(287, 34, 149, 'Executive Suite', 'Spacious suite with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 18000.00, 'hyatt_suite.jpg', 3, 3),

-- Pune Apartments
(288, 33, 150, '1 BHK City Suite', 'Cozy 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 7000.00, 'pune_city_1bhk.jpg', 3, 3),
(289, 33, 150, '2 BHK City Suite', 'Spacious 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 13000.00, 'pune_city_2bhk.jpg', 2, 2),
(290, 33, 151, '1 BHK Executive Suite', 'Modern 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine, Work desk', 8000.00, 'pune_executive_1bhk.jpg', 3, 3),
(291, 33, 151, '2 BHK Executive Suite', 'Contemporary 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room, Work desk', 15000.00, 'pune_executive_2bhk.jpg', 2, 2),

-- Pune Villas (Direct Booking)
(292, 35, 152, 'Garden Villa', 'Luxury villa with garden', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Private garden, Butler service', 35000.00, 'pune_garden_villa.jpg', 1, 1),
(293, 35, 153, 'Lake Villa', 'Exclusive villa with lake view', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Lake view, Private pool, Butler service', 40000.00, 'pune_lake_villa.jpg', 1, 1),

-- Pune Resorts
(294, 36, 154, 'Standard Room', 'Comfortable resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 9000.00, 'pune_valley_standard.jpg', 5, 5),
(295, 36, 154, 'Deluxe Room', 'Spacious deluxe room with valley view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 13000.00, 'pune_valley_deluxe.jpg', 3, 3),
(296, 36, 155, 'Standard Room', 'Cozy resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 8000.00, 'pune_hills_standard.jpg', 5, 5),
(297, 36, 155, 'Deluxe Room', 'Spacious deluxe room', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 12000.00, 'pune_hills_deluxe.jpg', 3, 3),

-- Shirdi Hotels
(298, 34, 156, 'Deluxe Room', 'Luxury room with temple view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 10000.00, 'sai_leela_deluxe.jpg', 5, 5),
(299, 34, 156, 'Executive Suite', 'Premium suite with temple view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 18000.00, 'sai_leela_suite.jpg', 3, 3),
(300, 34, 157, 'Deluxe Room', 'Modern room with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service', 9000.00, 'shirdi_grand_deluxe.jpg', 5, 5),
(301, 34, 157, 'Executive Suite', 'Spacious suite with garden view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Living room', 16000.00, 'shirdi_grand_suite.jpg', 3, 3),

-- Shirdi Apartments
(302, 33, 158, '1 BHK City Suite', 'Cozy 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine', 6000.00, 'shirdi_city_1bhk.jpg', 3, 3),
(303, 33, 158, '2 BHK City Suite', 'Spacious 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room', 12000.00, 'shirdi_city_2bhk.jpg', 2, 2),
(304, 33, 159, '1 BHK Executive Suite', 'Modern 1 bedroom suite', '1 Bedroom, 1 Bathroom, Kitchen, WiFi, TV, AC, Washing machine, Work desk', 7000.00, 'shirdi_executive_1bhk.jpg', 3, 3),
(305, 33, 159, '2 BHK Executive Suite', 'Contemporary 2 bedroom suite', '2 Bedrooms, 2 Bathrooms, Kitchen, WiFi, TV, AC, Washing machine, Living room, Work desk', 13000.00, 'shirdi_executive_2bhk.jpg', 2, 2),

-- Shirdi Villas (Direct Booking)
(306, 35, 160, 'Garden Villa', 'Luxury villa with garden', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Private garden, Butler service', 30000.00, 'shirdi_garden_villa.jpg', 1, 1),
(307, 35, 161, 'Lake Villa', 'Exclusive villa with lake view', '4 Bedrooms, 4 Bathrooms, Kitchen, WiFi, TV, AC, Lake view, Private pool, Butler service', 35000.00, 'shirdi_lake_villa.jpg', 1, 1),

-- Shirdi Resorts
(308, 36, 162, 'Standard Room', 'Comfortable resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 8000.00, 'shirdi_valley_standard.jpg', 5, 5),
(309, 36, 162, 'Deluxe Room', 'Spacious deluxe room with valley view', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 12000.00, 'shirdi_valley_deluxe.jpg', 3, 3),
(310, 36, 163, 'Standard Room', 'Cozy resort room', 'King bed, WiFi, TV, AC, Mini bar, Room service', 7000.00, 'shirdi_hills_standard.jpg', 5, 5),
(311, 36, 163, 'Deluxe Room', 'Spacious deluxe room', 'King bed, WiFi, TV, AC, Mini bar, Room service, Balcony', 11000.00, 'shirdi_hills_deluxe.jpg', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `room_types`
--

CREATE TABLE `room_types` (
  `id` int(11) NOT NULL,
  `type_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_types`
--

-- Delete all room types
DELETE FROM `room_types`;

-- Insert room types
INSERT INTO `room_types` (`id`, `type_name`) VALUES
(33, 'Apartment'),
(34, 'Hotel'),
(35, 'Villa'),
(36, 'Resort');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `created_at`) VALUES
(1, 'Rohan', 'toyota@gmail.com', '09403874157', '$2y$10$NLB0aGb4tIcwVmMVmOh/Xep0vZlfLmPYSvVKcZCy5qvWCVqXk9AwK', '2025-04-29 17:29:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `destinations`
--
ALTER TABLE `destinations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_type_id` (`room_type_id`),
  ADD KEY `destination_id` (`destination_id`);

--
-- Indexes for table `room_types`
--
ALTER TABLE `room_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `destinations`
--
ALTER TABLE `destinations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=221;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=221;

--
-- AUTO_INCREMENT for table `room_types`
--
ALTER TABLE `room_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`);

--
-- Constraints for table `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `rooms_ibfk_1` FOREIGN KEY (`room_type_id`) REFERENCES `room_types` (`id`),
  ADD CONSTRAINT `rooms_ibfk_2` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`id`);